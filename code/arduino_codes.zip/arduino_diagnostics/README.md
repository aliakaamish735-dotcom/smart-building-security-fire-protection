# Arduino Component Diagnostics — Sensors Project

A standalone, menu-driven test sketch for verifying every sensor and
actuator works correctly — **separate from the real firmware** in
`../arduino_firmware_modular/`. Use this:

- **During assembly** — test each component right after wiring it,
  before moving on to the next, instead of discovering a problem only
  once everything is connected.
- **When something breaks later** — re-upload this sketch and isolate
  exactly which component is at fault, without touching your real
  firmware code.

## How to use

1. Copy this whole folder, rename it to `sensors_project_diagnostics`
   (folder name must match the `.ino` filename).
2. Open `sensors_project_diagnostics.ino` in the Arduino IDE.
3. Upload it.
4. Open **Tools → Serial Monitor**, set baud rate to **9600** and line
   ending to **"Newline"**.
5. Type a menu key (e.g. `1`) and press Enter to run that test. Type
   `M` any time to see the menu again.

## What each test checks

| Key | Tests | What a failure usually means |
|---|---|---|
| `1` | I2C bus scanner | Confirms PCF8574 (0x20) is visible on SDA/SCL — the TCRT5000 is analog and won't appear here, so a missing 0x20 points specifically to the keypad expander's wiring |
| `2` | TCRT5000 IR reflective sensor | Reads raw analog value (0-1023) and compares to `PHOTOCELL_THRESHOLD`; if detection triggers backwards, flip `>` to `<` in the driver |
| `3` | PCF8574 + keypad | No PCF8574 ACK = check A0/A1/A2 tied to GND; PCF8574 OK but no keypresses = row/column wiring |
| `4` | DHT11 | NaN readings = DATA wire or missing pull-up resistor |
| `5` | HX711 + load cell | Not responding = DT/SCK wiring; responds but weight is wrong = needs real calibration (see `/data/calibration_log_template.csv`) |
| `6` | Flow sensor | Zero pulses while water is flowing = signal wire on D2, or check the sensor's flow direction arrow |
| `7` | Servo | Doesn't move = confirm it's on its own external 5V supply, not the Arduino's 5V pin |
| `8` | DFPlayer Mini | Not detected = check TX/RX wiring (**and the 1kΩ resistor on D7**) and that the SD card has tracks `0001.mp3`-`0007.mp3` |
| `9` | Buzzer | Silent = check signal wire on D3 |
| `A`/`B`/`C` | Relay CH1/CH2/CH3 (pump/humidifier/fan) | Relay clicks but load doesn't run = check external supply wiring on COM/NO, not the Arduino side; load runs continuously and only stops during the test = your relay board is active-HIGH, not active-LOW (see `RelayBank_Driver.h`) |
| `D` | ESP-01 AT commands only (no WiFi) | No response = check the ESP-01 Adapter is powered from 5V, D11/D12 wiring (**with the voltage divider on D12**), and try 115200 baud if 9600 doesn't work |
| `E` | ESP-01 full WiFi + HTTP round-trip to the Flask server | Passes D but fails E = check `WIFI_SSID`/`WIFI_PASSWORD`/`SERVER_HOST`/`DEVICE_KEY` in `CalibrationConstants.h`, and that `app.py` is actually running |

## ⚠️ Keep `Config.h` and `CalibrationConstants.h` in sync

This folder has its **own copies** of `Config.h` and
`CalibrationConstants.h`, identical to the ones in
`../arduino_firmware_modular/`. If you change a pin assignment or a
calibration value in the real firmware, copy the updated file(s) here
too — otherwise this tool will test the wrong pins or use stale
calibration numbers without you realizing it.
