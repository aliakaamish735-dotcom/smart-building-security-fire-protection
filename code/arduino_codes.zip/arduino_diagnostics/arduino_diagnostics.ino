/*
 * Sensors Project — Component Diagnostics Sketch
 *
 * A standalone, menu-driven test tool — separate from the real
 * firmware — for verifying every sensor/actuator works correctly
 * BEFORE trusting the full system, and for isolating a specific
 * component later if something breaks.
 *
 * WHY THIS IS ITS OWN SKETCH, NOT PART OF THE REAL FIRMWARE:
 *   - Some tests are blocking/destructive by nature (sweeping the
 *     servo, firing relays, playing every audio track) — you don't
 *     want that logic anywhere near the real fire-protection/entry-
 *     security state machines.
 *   - You can wire up ONE component at a time during assembly and
 *     confirm it here before moving to the next, instead of only
 *     finding out something's wrong once everything is wired.
 *   - If something misbehaves after the system's been running a
 *     while, re-upload this sketch and isolate exactly which
 *     component is at fault without touching the real firmware code.
 *
 * HOW TO USE:
 *   1. Upload this sketch (folder name must match: "sensors_project_diagnostics").
 *   2. Open Serial Monitor, set baud to 9600, line ending to "Newline".
 *   3. Type a menu key (e.g. "1") and press Enter to run that test.
 *   4. Read the printed result. Type "M" + Enter any time to see the
 *      menu again.
 *
 * IMPORTANT: Config.h and CalibrationConstants.h are COPIES of the
 * ones in code/arduino_firmware_modular/. If you change a pin or a
 * calibration value in the real firmware, copy the updated file(s)
 * here too, or this diagnostic tool will test the wrong pins.
 *
 * Uses the same 5 libraries as the real firmware: DHT sensor library
 * (Adafruit) + Adafruit Unified Sensor, HX711 (Bogdan Necula),
 * DFRobotDFPlayerMini (DFRobot), ArduinoJson (Benoit Blanchon).
 * Servo/Wire/SoftwareSerial are Arduino-core built-ins.
 */

#include <Wire.h>
#include <Servo.h>
#include <DHT.h>
#include <HX711.h>
#include <SoftwareSerial.h>
#include <DFRobotDFPlayerMini.h>
#include <ArduinoJson.h>
#include "Config.h"
#include "CalibrationConstants.h"

// ----------------------- Shared objects -----------------------
DHT dht(PIN_DHT, DHTTYPE);
HX711 scale;
Servo doorServo;
SoftwareSerial dfPlayerSerial(PIN_DFPLAYER_TX, PIN_DFPLAYER_RX);
DFRobotDFPlayerMini dfPlayer;
SoftwareSerial espSerial(PIN_ESP_RX, PIN_ESP_TX);

volatile unsigned long flowPulseCount = 0;
void flowPulseISR() { flowPulseCount++; }

const char KEYPAD_MAP[4][4] = {
  {'1', '2', '3', 'A'},
  {'4', '5', '6', 'B'},
  {'7', '8', '9', 'C'},
  {'*', '0', '#', 'D'}
};

// =========================================================
void printMenu() {
  Serial.println();
  Serial.println(F("========== Sensors Project — Component Diagnostics =========="));
  Serial.println(F("1 - I2C bus scanner (confirms PCF8574 @0x20 is visible)"));
  Serial.println(F("2 - TCRT5000 IR reflective sensor (AO=A2, 10s)"));
  Serial.println(F("3 - PCF8574 + keypad (press keys, 15s)"));
  Serial.println(F("4 - DHT11 temperature/humidity (5 readings)"));
  Serial.println(F("5 - HX711 + load cell (tare, then live weight, 10s)"));
  Serial.println(F("6 - Flow sensor (live pulse/flow reading, 10s — needs water flowing)"));
  Serial.println(F("7 - Servo door lock (open/close sweep)"));
  Serial.println(F("8 - DFPlayer Mini (plays tracks 1-7 in sequence)"));
  Serial.println(F("9 - Buzzer (on 1s / off 1s, x3)"));
  Serial.println(F("A - Relay CH1 / Pump (on 2s / off)"));
  Serial.println(F("B - Relay CH2 / Humidifier (on 2s / off)"));
  Serial.println(F("C - Relay CH3 / Fan (on 2s / off)"));
  Serial.println(F("D - ESP-01 AT command test (checks the module responds at all)"));
  Serial.println(F("E - ESP-01 WiFi + HTTP test (joins WiFi, posts one test reading to the server)"));
  Serial.println(F("M - Show this menu again"));
  Serial.println(F("============================================================"));
  Serial.println(F("Type a key + Enter to run a test."));
}

void setup() {
  Serial.begin(9600);
  while (!Serial) { ; }
  Wire.begin();
  printMenu();
}

void loop() {
  if (Serial.available()) {
    String input = Serial.readStringUntil('\n');
    input.trim();
    if (input.length() == 0) return;
    char key = toupper(input.charAt(0));

    switch (key) {
      case '1': testI2CScanner(); break;
      case '2': testTcrt5000(); break;
      case '3': testKeypad(); break;
      case '4': testDht11(); break;
      case '5': testHx711(); break;
      case '6': testFlowSensor(); break;
      case '7': testServo(); break;
      case '8': testDfPlayer(); break;
      case '9': testBuzzer(); break;
      case 'A': testRelay(PIN_RELAY_PUMP, "Pump (CH1)"); break;
      case 'B': testRelay(PIN_RELAY_HUMIDIFIER, "Humidifier (CH2)"); break;
      case 'C': testRelay(PIN_RELAY_FAN, "Fan (CH3)"); break;
      case 'D': testEsp01AT(); break;
      case 'E': testEsp01WifiAndHttp(); break;
      case 'M': printMenu(); break;
      default:
        Serial.println(F("Unrecognized option. Type M for the menu."));
    }
    Serial.println(F("\n--- Test complete. Type M for menu, or another key to run again. ---"));
  }
}

// =========================================================
// 1) I2C BUS SCANNER
// =========================================================
void testI2CScanner() {
  Serial.println(F("\n[I2C Scanner] Scanning addresses 1-126..."));
  int found = 0;
  for (uint8_t addr = 1; addr < 127; addr++) {
    Wire.beginTransmission(addr);
    uint8_t error = Wire.endTransmission();
    if (error == 0) {
      Serial.print(F("  Device found at 0x"));
      if (addr < 16) Serial.print('0');
      Serial.print(addr, HEX);
      if (addr == PCF8574_ADDR) Serial.print(F("  <-- expected PCF8574"));
      Serial.println();
      found++;
    }
  }
  if (found == 0) {
    Serial.println(F("  No I2C devices found! Check SDA(A4)/SCL(A5) wiring for PCF8574 keypad."));
  } else {
    Serial.print(F("[I2C Scanner] Done. "));
    Serial.print(found);
    Serial.println(F(" device(s) found."));
    Serial.println(F("  Expected: 0x20 (PCF8574 keypad). Photocell is analog, so it will NOT appear in I2C scanner."));
  }
}

// =========================================================
// 2) TCRT5000 IR REFLECTIVE PHOTOELECTRIC SENSOR
// =========================================================
// TCRT5000 module wiring:
// VCC -> 5V
// GND -> GND
// AO  -> A2 (PIN_PHOTOCELL) — the only signal wire this needs.
//
// DO is intentionally NOT connected. The module's own "DO" pin label
// is a coincidental name clash with Arduino's D0 pin (USB/Serial RX) —
// they are NOT the same thing, and wiring them together creates a real
// conflict with Serial Monitor and uploads. One wire (AO) is enough
// for presence detection, so DO is left disconnected entirely rather
// than routed to a different free pin — simpler wiring, same result.
//
// This test uses analogRead() and compares against PHOTOCELL_THRESHOLD
// (CalibrationConstants.h, 0-1023 scale) — the module's onboard trim
// potentiometer handles coarse sensitivity in hardware; this constant
// lets you fine-tune in software on top of that.

void testTcrt5000() {
  Serial.println(F("\n[TCRT5000] Reading IR reflective sensor for 10 seconds..."));
  Serial.println(F("  Wiring: VCC->5V, GND->GND, AO->A2. DO is NOT connected (see comment above)."));
  Serial.println(F("  Put your hand/object in front of the black sensor head."));
  Serial.print(F("  Comparing against PHOTOCELL_THRESHOLD = "));
  Serial.println(PHOTOCELL_THRESHOLD);

  pinMode(PIN_PHOTOCELL, INPUT);

  unsigned long start = millis();
  while (millis() - start < 10000) {
    int analogRaw = analogRead(PIN_PHOTOCELL);

    // NOTE: untested detection direction on your specific module — if
    // this triggers backwards (detects when nothing is there, stays
    // quiet when something is), change > to < below.
    bool objectDetected = (analogRaw > PHOTOCELL_THRESHOLD);

    Serial.print(F("  AO raw: "));
    Serial.print(analogRaw);
    Serial.print(F(" / 1023"));
    Serial.println(objectDetected ? F("  <-- OBJECT / PERSON DETECTED") : F(""));

    delay(300);
  }

  Serial.println(F("  Tip: adjust the blue onboard potentiometer for coarse sensitivity, and PHOTOCELL_THRESHOLD in CalibrationConstants.h for fine tuning."));
}

// =========================================================
// 3) PCF8574 + KEYPAD
// =========================================================
void pcfWrite(uint8_t value) {
  Wire.beginTransmission(PCF8574_ADDR);
  Wire.write(value);
  Wire.endTransmission();
}
uint8_t pcfRead() {
  Wire.requestFrom((int)PCF8574_ADDR, 1);
  if (Wire.available()) return Wire.read();
  return 0xFF;
}
char scanKeypadOnce() {
  for (uint8_t row = 0; row < 4; row++) {
    uint8_t rowMask = ~(1 << row) & 0x0F;
    uint8_t output = (rowMask & 0x0F) | 0xF0;
    pcfWrite(output);
    delayMicroseconds(50);
    uint8_t colState = pcfRead() >> 4;
    for (uint8_t col = 0; col < 4; col++) {
      if (!(colState & (1 << col))) {
        delay(15); // debounce the initial contact bounce
        char pressedKey = KEYPAD_MAP[row][col];

        // Wait here until the key is actually released, so the caller's
        // loop doesn't call scanKeypadOnce() again while the same
        // physical press (100-300ms+) is still ongoing. Without this,
        // one press gets detected repeatedly every ~15ms for as long
        // as the finger is still on the key.
        while (true) {
          pcfWrite(output);
          delayMicroseconds(50);
          uint8_t stillPressed = (pcfRead() >> 4) & (1 << col);
          if (stillPressed) break; // bit is 1 again = released (active-low read)
          delay(10);
        }
        delay(20); // small extra debounce after release before allowing the next press

        pcfWrite(0xFF);
        return pressedKey;
      }
    }
  }
  pcfWrite(0xFF);
  return '\0';
}

void testKeypad() {
  Serial.println(F("\n[Keypad] Checking PCF8574 is responding..."));
  Wire.beginTransmission(PCF8574_ADDR);
  if (Wire.endTransmission() != 0) {
    Serial.println(F("  FAIL: PCF8574 did not ACK at 0x20. Check wiring and that A0/A1/A2 are all tied to GND."));
    return;
  }
  Serial.println(F("  PCF8574 responded OK."));
  pcfWrite(0xFF);
  Serial.println(F("  Press keys on the keypad for 15 seconds — each press should print below..."));
  unsigned long start = millis();
  while (millis() - start < 15000) {
    char key = scanKeypadOnce();
    if (key != '\0') {
      Serial.print(F("  Key pressed: "));
      Serial.println(key);
    }
  }
}

// =========================================================
// 4) DHT11
// =========================================================
void testDht11() {
  Serial.println(F("\n[DHT11] Taking 5 readings, 2s apart..."));
  dht.begin();
  for (int i = 0; i < 5; i++) {
    delay(2000);
    float t = dht.readTemperature();
    float h = dht.readHumidity();
    if (isnan(t) || isnan(h)) {
      Serial.println(F("  FAIL: read returned NaN. Check DATA wire on D8 and the pull-up resistor."));
    } else {
      Serial.print(F("  Temp: "));
      Serial.print(t);
      Serial.print(F(" C   Humidity: "));
      Serial.print(h);
      Serial.println(F(" %"));
    }
  }
}

// =========================================================
// 5) HX711 + LOAD CELL
// =========================================================
void testHx711() {
  Serial.println(F("\n[HX711] Initializing..."));
  scale.begin(PIN_HX711_DT, PIN_HX711_SCK);
  if (!scale.wait_ready_timeout(2000)) {
    Serial.println(F("  FAIL: HX711 not responding. Check DT(A0)/SCK(A1) wiring and power."));
    return;
  }
  Serial.println(F("  HX711 responding. Taring with current load (should be empty)..."));
  scale.set_scale(LOADCELL_SCALE_FACTOR);
  scale.tare();
  Serial.println(F("  Tare done. Reading live weight for 10 seconds — place a known weight to check..."));
  unsigned long start = millis();
  while (millis() - start < 10000) {
    if (scale.is_ready()) {
      long raw = scale.read();
      float grams = scale.get_units(3);
      Serial.print(F("  Raw: "));
      Serial.print(raw);
      Serial.print(F("   Weight: "));
      Serial.print(grams);
      Serial.println(F(" g  (using LOADCELL_SCALE_FACTOR from CalibrationConstants.h)"));
    } else {
      Serial.println(F("  (not ready this tick)"));
    }
    delay(500);
  }
}

// =========================================================
// 6) FLOW SENSOR
// =========================================================
void testFlowSensor() {
  Serial.println(F("\n[Flow Sensor] Listening for pulses for 10 seconds — run water through the sensor now..."));
  pinMode(PIN_FLOW, INPUT_PULLUP);
  attachInterrupt(digitalPinToInterrupt(PIN_FLOW), flowPulseISR, FALLING);
  flowPulseCount = 0;

  unsigned long start = millis();
  while (millis() - start < 10000) {
    delay(1000);
    noInterrupts();
    unsigned long pulses = flowPulseCount;
    flowPulseCount = 0;
    interrupts();
    float flowLpm = (pulses / 1.0) / FLOW_CALIBRATION_FACTOR;
    Serial.print(F("  Pulses this second: "));
    Serial.print(pulses);
    Serial.print(F("   Flow: "));
    Serial.print(flowLpm, 3);
    Serial.println(F(" L/min"));
  }
  detachInterrupt(digitalPinToInterrupt(PIN_FLOW));
  Serial.println(F("  If pulses stayed at 0 the whole time, check the yellow signal wire on D2 and that water is actually flowing."));
}

// =========================================================
// 7) SERVO
// =========================================================
void testServo() {
  Serial.println(F("\n[Servo] Attaching and sweeping open -> closed..."));
  doorServo.attach(PIN_SERVO);
  Serial.println(F("  Moving to 0 degrees (closed)..."));
  doorServo.write(0);
  delay(1500);
  Serial.println(F("  Moving to 180 degrees (open)..."));
  doorServo.write(180);
  delay(1500);
  Serial.println(F("  Moving back to 0 degrees (closed)..."));
  doorServo.write(0);
  delay(1000);
  doorServo.detach();
  Serial.println(F("  Done. If the servo didn't move: check it's on its OWN external 5V supply, not the Arduino's 5V pin, and that grounds are common."));
}

// =========================================================
// 8) DFPLAYER MINI
// =========================================================
void testDfPlayer() {
  Serial.println(F("\n[DFPlayer Mini] Connecting..."));
  dfPlayerSerial.begin(9600);
  if (!dfPlayer.begin(dfPlayerSerial)) {
    Serial.println(F("  FAIL: DFPlayer not detected. Check TX/RX wiring (D6/D7 + 1k resistor on D7), SD card inserted, and power."));
    return;
  }
  Serial.println(F("  DFPlayer connected. Setting volume to 24/30."));
  dfPlayer.volume(24);
  const char* names[7] = {
    "PLEASE ENTER PASSWORD", "ACCESS ACCEPTED", "ACCESS DENIED", "ACCESS DENIED THIEF ATTEMPT",
    "HIGH TEMPERATURE DETECTED", "PIPE BLOCKAGE DETECTED", "SYSTEM STABLE"
  };
  for (int track = 1; track <= 7; track++) {
    Serial.print(F("  Playing track "));
    Serial.print(track);
    Serial.print(F(" ("));
    Serial.print(names[track - 1]);
    Serial.println(F(")..."));
    dfPlayer.play(track);
    delay(3000); // adjust if your recordings are longer
  }
  Serial.println(F("  Done. If you heard nothing: check the speaker is on SPK1/SPK2, and the SD card has tracks 0001-0007.mp3."));
}

// =========================================================
// 9) BUZZER
// =========================================================
void testBuzzer() {
  Serial.println(F("\n[Buzzer] Toggling on/off 3 times..."));
  pinMode(PIN_BUZZER, OUTPUT);
  for (int i = 0; i < 3; i++) {
    Serial.println(F("  ON"));
    digitalWrite(PIN_BUZZER, HIGH);
    delay(1000);
    Serial.println(F("  OFF"));
    digitalWrite(PIN_BUZZER, LOW);
    delay(1000);
  }
}

// =========================================================
// A/B/C) RELAYS
// =========================================================
void testRelay(uint8_t pin, const char* label) {
  Serial.print(F("\n[Relay] Testing "));
  Serial.println(label);
  pinMode(pin, OUTPUT);
  digitalWrite(pin, HIGH); // off, assuming active-LOW board (see RelayBank_Driver.h notes)
  Serial.println(F("  Energizing relay (active-LOW: driving pin LOW)..."));
  digitalWrite(pin, LOW);
  Serial.println(F("  You should hear/feel the relay click, and its connected load should activate."));
  delay(2000);
  Serial.println(F("  De-energizing (driving pin HIGH)..."));
  digitalWrite(pin, HIGH);
  Serial.println(F("  Done. If the relay clicks but the load doesn't respond, check the external supply wiring on the load side (COM/NO), not the Arduino side."));
  Serial.println(F("  If the load runs continuously and stops only during this test, your relay board is active-HIGH, not active-LOW — see RelayBank_Driver.h."));
}

// =========================================================
// D) ESP-01 AT COMMAND TEST
// =========================================================
bool sendATCommand(const String& cmd, const String& expected, unsigned long timeoutMs, String& outResponse) {
  espSerial.println(cmd);
  unsigned long start = millis();
  outResponse = "";
  while (millis() - start < timeoutMs) {
    while (espSerial.available()) {
      outResponse += (char)espSerial.read();
      if (outResponse.indexOf(expected) != -1) return true;
    }
  }
  return false;
}

void testEsp01AT() {
  Serial.println(F("\n[ESP-01] Sending basic AT command..."));
  espSerial.begin(9600);
  String response;
  bool ok = sendATCommand("AT", "OK", 2000, response);
  Serial.print(F("  Response: "));
  Serial.println(response.length() ? response : F("(nothing received)"));
  if (ok) {
    Serial.println(F("  PASS: module responded to AT."));
  } else {
    Serial.println(F("  FAIL: no response. Check: ESP-01 Adapter powered from 5V, TX(ESP)->D11, RX(ESP)<-D12 THROUGH a voltage divider, and common ground."));
    Serial.println(F("  Also check baud rate — some modules default to 115200 instead of 9600."));
  }

  Serial.println(F("  Checking firmware version (AT+GMR)..."));
  sendATCommand("AT+GMR", "OK", 2000, response);
  Serial.println(response.length() ? response : F("  (no version info received)"));
}

// =========================================================
// E) ESP-01 WIFI + HTTP TEST
// =========================================================
void testEsp01WifiAndHttp() {
  Serial.println(F("\n[ESP-01] Full WiFi + HTTP test..."));
  espSerial.begin(9600);
  String response;

  Serial.println(F("  Setting station mode..."));
  sendATCommand("AT+CWMODE=1", "OK", 2000, response);

  Serial.print(F("  Joining WiFi network \""));
  Serial.print(WIFI_SSID);
  Serial.println(F("\" (this can take 10-20s)..."));
  String joinCmd = "AT+CWJAP=\"" + String(WIFI_SSID) + "\",\"" + String(WIFI_PASSWORD) + "\"";
  bool joined = sendATCommand(joinCmd, "OK", 20000, response);
  if (!joined) {
    Serial.println(F("  FAIL: could not join WiFi. Check WIFI_SSID/WIFI_PASSWORD in CalibrationConstants.h, and that the network is 2.4GHz (ESP8266 doesn't support 5GHz)."));
    return;
  }
  Serial.println(F("  WiFi joined successfully."));

  sendATCommand("AT+CIPMUX=0", "OK", 2000, response);

  Serial.print(F("  Sending a test POST to http://"));
  Serial.print(SERVER_HOST);
  Serial.print(':');
  Serial.print(SERVER_PORT);
  Serial.println(F("/api/ingest/sensors ..."));

  StaticJsonDocument<128> doc;
  doc["temp_c"] = 22.2;
  doc["humidity_pct"] = 41.0;
  doc["tank_weight_g"] = 0;
  doc["flow_lpm"] = 0;
  doc["proximity_detected"] = false;
  String jsonBody;
  serializeJson(doc, jsonBody);

  String request = "POST /api/ingest/sensors HTTP/1.1\r\n";
  request += "Host: " + String(SERVER_HOST) + "\r\n";
  request += "Content-Type: application/json\r\n";
  request += "X-Device-Key: " + String(DEVICE_KEY) + "\r\n";
  request += "Content-Length: " + String(jsonBody.length()) + "\r\n";
  request += "Connection: close\r\n\r\n";
  request += jsonBody;

  String startCmd = "AT+CIPSTART=\"TCP\",\"" + String(SERVER_HOST) + "\"," + String(SERVER_PORT);
  if (!sendATCommand(startCmd, "OK", 5000, response)) {
    Serial.println(F("  FAIL: could not open TCP connection. Is app.py running? Is SERVER_HOST your laptop's current LAN IP?"));
    return;
  }

  String sendCmd = "AT+CIPSEND=" + String(request.length());
  espSerial.println(sendCmd);
  delay(100);
  espSerial.print(request);

  unsigned long start = millis();
  String httpResponse = "";
  while (millis() - start < 5000) {
    while (espSerial.available()) httpResponse += (char)espSerial.read();
    if (httpResponse.indexOf("CLOSED") != -1) break;
  }
  sendATCommand("AT+CIPCLOSE", "OK", 2000, response);

  if (httpResponse.indexOf("200") != -1 || httpResponse.indexOf("\"status\"") != -1) {
    Serial.println(F("  PASS: server responded successfully. Check the dashboard for a new reading."));
  } else {
    Serial.println(F("  FAIL or unexpected response. Raw response below:"));
  }
  Serial.println(httpResponse.length() ? httpResponse : F("  (no response received)"));
  Serial.println(F("  If this fails but the AT-only test (D) passed: check DEVICE_KEY matches app.py's DEVICE_API_KEY, and that SERVER_HOST/SERVER_PORT are correct."));
}
