/*
 * CalibrationConstants.h — Sensors Project
 *
 * Every calibration constant, threshold, and credential the firmware
 * needs lives HERE and nowhere else. Nothing in the driver or
 * state-machine files should hard-code a number that could plausibly
 * change per-unit or per-deployment — that's exactly the pattern the
 * course proposal's Firmware requirements section asks you to avoid
 * ("calibration constants stored in EEPROM or a dedicated constants
 * file; not hard-coded inline").
 *
 * HOW TO FILL THIS IN FOR REAL (do this before your final report):
 *   1. Run the load-cell calibration procedure (known reference weights,
 *      3 trials minimum) and replace LOADCELL_SCALE_FACTOR below.
 *   2. Run the flow-sensor calibration procedure (timed volume
 *      collection, 3 trials minimum) and replace FLOW_CALIBRATION_FACTOR.
 *   3. Record your raw/reference numbers in
 *      /data/calibration_log_template.csv — that table IS your
 *      report's "Calibration Procedures and Results" section.
 *
 * OPTIONAL BONUS: EEPROMCalibration.h/.cpp (same folder) shows how to
 * persist these two calibration factors in EEPROM instead, so they
 * survive a re-flash without editing source code — mentioned in your
 * report as a maintainability improvement.
 */
#ifndef CALIBRATION_CONSTANTS_H
#define CALIBRATION_CONSTANTS_H

// ----------------------------------------------------------------
// LOAD CELL (HX711) — grams per raw ADC unit, see calibration proc.
// TODO: replace with your measured value (currently an initial guess).
// ----------------------------------------------------------------
constexpr float LOADCELL_SCALE_FACTOR = 420.0;

// ----------------------------------------------------------------
// FLOW SENSOR (YF-S201 / YF-B1) — pulses per second per L/min.
// TODO: replace with your measured value (currently the datasheet's
// typical value, not a per-unit calibration).
// ----------------------------------------------------------------
constexpr float FLOW_CALIBRATION_FACTOR = 7.5;

// ----------------------------------------------------------------
// FIRE-PROTECTION THRESHOLDS — must match system_settings defaults
// in the web app's db.py so the Arduino and dashboard agree.
// ----------------------------------------------------------------
constexpr float FIRE_THRESHOLD_C       = 45.0;   // trip point to start the sequence
constexpr float NORMAL_TEMP_C          = 28.0;   // temp must fall to this before venting
constexpr float TARGET_WEIGHT_G        = 2000.0; // tank fill target
constexpr float TARGET_HUMIDITY_PCT    = 70.0;   // humidifier runs until this is reached
constexpr float NORMAL_HUMIDITY_PCT    = 50.0;   // fan runs until humidity drops to this
constexpr float FLOW_BLOCKAGE_LPM      = 0.05;   // flow at/below this while pump runs = blockage

// ----------------------------------------------------------------
// ENTRY SECURITY THRESHOLDS
// ----------------------------------------------------------------
constexpr int   MAX_WRONG_ATTEMPTS     = 3;    // N from the algorithm doc
constexpr int   PHOTOCELL_THRESHOLD    = 500;  // 0-1023 (10-bit analogRead), tune to your door's mounting distance and lighting.
// TCRT5000 also has an onboard trim potentiometer that adjusts the comparator
// threshold in hardware — use both together: pot for coarse range, this constant for fine tuning.
constexpr unsigned long PROXIMITY_DEBOUNCE_MS = 8000;
constexpr unsigned long KEYPAD_TIMEOUT_MS     = 15000;
constexpr unsigned long DOOR_OPEN_MS          = 5000;

// ----------------------------------------------------------------
// SAMPLING / TIMING — justify these in your report's Firmware section:
//   - DHT11 can't physically sample faster than ~1 Hz; 5s posting also
//     limits WiFi/HTTP traffic and matches the fire sequence's expected
//     pump-fill timescale (seconds, not milliseconds).
//   - 3s command polling balances dashboard-command responsiveness
//     against not flooding the ESP-01/server with GET requests.
// ----------------------------------------------------------------
constexpr unsigned long SENSOR_POST_INTERVAL   = 5000;  // ms between sensor reads + posts
constexpr unsigned long COMMAND_POLL_INTERVAL  = 3000;  // ms between dashboard command polls

// ----------------------------------------------------------------
// NETWORK / DEVICE CREDENTIALS
// TODO: change WIFI_SSID / WIFI_PASSWORD / SERVER_HOST to your own,
// and change DEVICE_KEY to a non-default value that matches
// DEVICE_API_KEY in the web app's app.py.
// ----------------------------------------------------------------
static const char* WIFI_SSID     = "TP-LINK";
static const char* WIFI_PASSWORD = "71089909";
static const char* SERVER_HOST   = "192.168.1.103";   // your laptop's LAN IP
constexpr int       SERVER_PORT  = 5000;
static const char* DEVICE_KEY    = "lab76l-shared-secret-change-me";

#endif // CALIBRATION_CONSTANTS_H
