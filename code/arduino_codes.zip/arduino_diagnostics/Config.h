/*
 * Config.h — Sensors Project
 *
 * Pin assignments ONLY. This is deliberately separate from
 * CalibrationConstants.h: pins describe *wiring* (changes if you
 * rewire the board), calibration constants describe *measurement*
 * (changes if you recalibrate a sensor). Keeping them apart means
 * rewiring never risks accidentally touching a calibration value and
 * vice versa.
 *
 * Matches Circuit_summary.txt exactly — see docs/SensorsProject_Wiring_Diagram.png
 * and docs/SensorsProject_Installation_Guide.pdf for the full wiring reference.
 */
#ifndef CONFIG_H
#define CONFIG_H

// D0, D1 intentionally unused — reserved for USB serial / CSV debug output.
constexpr uint8_t PIN_FLOW             = 2;   // YF-S201/YF-B1 flow sensor signal (interrupt)
constexpr uint8_t PIN_BUZZER           = 3;   // Active buzzer signal
constexpr uint8_t PIN_RELAY_PUMP       = 4;   // Pump relay IN (active-LOW)
constexpr uint8_t PIN_SERVO            = 5;   // SG90 servo signal (door lock)
constexpr uint8_t PIN_DFPLAYER_RX      = 6;   // Arduino RX <- DFPlayer TX
constexpr uint8_t PIN_DFPLAYER_TX      = 7;   // Arduino TX -> DFPlayer RX (through 1k resistor)
constexpr uint8_t PIN_DHT              = 8;   // DHT11 data
constexpr uint8_t PIN_RELAY_HUMIDIFIER = 9;   // Humidifier relay IN (active-LOW)
constexpr uint8_t PIN_RELAY_FAN        = 10;  // Fan relay IN (active-LOW)
constexpr uint8_t PIN_ESP_RX           = 11;  // Arduino SoftwareSerial RX <- ESP-01 TX
constexpr uint8_t PIN_ESP_TX           = 12;  // Arduino SoftwareSerial TX -> ESP-01 RX (voltage divider!)
constexpr uint8_t PIN_STATUS_LED       = 13;
constexpr uint8_t PIN_HX711_DT         = A0;
constexpr uint8_t PIN_HX711_SCK        = A1;
constexpr uint8_t PIN_PHOTOCELL        = A2;  // TCRT5000 IR reflective sensor (analog reflectance output)
// A4 (SDA) / A5 (SCL) used implicitly by Wire.h for the PCF8574 keypad expander

constexpr uint8_t PCF8574_ADDR = 0x20;

#define DHTTYPE DHT11

#endif // CONFIG_H
