/*
 * FireProtectionSystem.h — Sensors Project
 *
 * Implements System 2 from the algorithm doc, orchestrating the
 * individual drivers:
 *
 *   Read temp/humidity continuously
 *   IF temp > FIRE_THRESHOLD: alarm LED, pump ON
 *     WHILE tank weight < TARGET_WEIGHT: read load cell
 *       IF flow == 0: pump OFF, buzzer, "PIPE BLOCKAGE DETECTED", stop
 *     pump OFF, humidifier ON
 *     WHILE temp > NORMAL_TEMPERATURE: keep humidifier ON
 *     IF temp <= NORMAL_TEMPERATURE AND humidity >= TARGET_HUMIDITY:
 *       humidifier OFF, fan ON
 *       WHILE humidity > NORMAL_HUMIDITY: keep fan ON
 *       fan OFF, "SYSTEM STABLE"
 *
 * Runs LOCALLY on the Arduino, never waiting on the server — a network
 * hiccup must never block water reaching a fire. wifi.postSensorReadings()
 * reports the resulting stage to the dashboard afterward purely for display.
 */
#ifndef FIRE_PROTECTION_SYSTEM_H
#define FIRE_PROTECTION_SYSTEM_H

#include <Arduino.h>
#include "Config.h"
#include "CalibrationConstants.h"
#include "DHT11_Driver.h"
#include "HX711_Driver.h"
#include "FlowSensor_Driver.h"
#include "RelayBank_Driver.h"
#include "DFPlayerAudio_Driver.h"
#include "BuzzerAlarm_Driver.h"

enum class FireStage { Idle, FireDetected, FillingTank, Blocked, Humidifying, Venting, Stable };

class FireProtectionSystem {
public:
  FireProtectionSystem(DHT11Driver& dht, HX711Driver& loadCell, FlowSensorDriver& flow,
                        RelayBankDriver& relays, DFPlayerAudioDriver& audio,
                        BuzzerAlarmDriver& buzzer)
    : dht(dht), loadCell(loadCell), flow(flow), relays(relays),
      audio(audio), buzzer(buzzer) {}

  void begin() {
    dht.begin();
    loadCell.begin();
    flow.begin();
    relays.begin();
    pinMode(PIN_STATUS_LED, OUTPUT);
  }

  // Call once per SENSOR_POST_INTERVAL — advances the state machine by
  // one step. Returns true if the DHT11 read succeeded this cycle
  // (false means temp/humidity are stale — caller should mark them
  // invalid in any payload it sends).
  bool step() {
    bool dhtOk = dht.read();
    lastWeightG = loadCell.readWeightGrams();
    lastFlowLpm = flow.computeFlowLpm(SENSOR_POST_INTERVAL);

    if (!dhtOk) {
      Serial.println(F("WARNING: DHT11 read failed this cycle, skipping fire-sequence step."));
    } else {
      advance();
    }

    Serial.print(F("Fire stage: "));
    Serial.println(stageName());
    return dhtOk;
  }

  // Dashboard-issued manual reset once a physical blockage is cleared.
  void clearBlockage() {
    if (stage == FireStage::Blocked) {
      Serial.println(F("Blockage cleared from dashboard - resetting fire sequence."));
      buzzer.silence();
      stage = FireStage::Idle;
      digitalWrite(PIN_STATUS_LED, LOW);
    }
  }

  const char* stageName() const {
    switch (stage) {
      case FireStage::Idle: return "IDLE";
      case FireStage::FireDetected: return "FIRE_DETECTED";
      case FireStage::FillingTank: return "FILLING_TANK";
      case FireStage::Blocked: return "BLOCKED";
      case FireStage::Humidifying: return "HUMIDIFYING";
      case FireStage::Venting: return "VENTING";
      case FireStage::Stable: return "STABLE";
      default: return "UNKNOWN";
    }
  }

  float getLastTempC() const { return dht.getTempC(); }
  float getLastHumidityPct() const { return dht.getHumidityPct(); }
  float getLastWeightG() const { return lastWeightG; }
  float getLastFlowLpm() const { return lastFlowLpm; }

private:
  DHT11Driver& dht;
  HX711Driver& loadCell;
  FlowSensorDriver& flow;
  RelayBankDriver& relays;
  DFPlayerAudioDriver& audio;
  BuzzerAlarmDriver& buzzer;

  FireStage stage = FireStage::Idle;
  float lastWeightG = 0.0;
  float lastFlowLpm = 0.0;

  void advance() {
    float tempC = dht.getTempC();
    float humidityPct = dht.getHumidityPct();

    switch (stage) {
      case FireStage::Idle:
        if (tempC > FIRE_THRESHOLD_C) {
          Serial.println(F("FIRE DETECTED - starting suppression sequence."));
          audio.play(VoicePrompt::HighTemperature);
          digitalWrite(PIN_STATUS_LED, HIGH);
          stage = FireStage::FireDetected;
        }
        break;

      case FireStage::FireDetected:
        relays.setPump(true);
        stage = FireStage::FillingTank;
        break;

      case FireStage::FillingTank:
        relays.setPump(true);
        if (flow.isBlocked(lastFlowLpm)) {
          Serial.println(F("PIPE BLOCKAGE - stopping pump, halting sequence."));
          relays.setPump(false);
          audio.play(VoicePrompt::PipeBlockage);
          buzzer.sound();
          stage = FireStage::Blocked;
        } else if (lastWeightG >= TARGET_WEIGHT_G) {
          Serial.println(F("Tank full - switching to humidifier."));
          relays.setPump(false);
          relays.setHumidifier(true);
          stage = FireStage::Humidifying;
        }
        break;

      case FireStage::Blocked:
        // Stays here until clearBlockage() is called from the dashboard
        // — a network-only reset would be unsafe for a real blockage.
        relays.setPump(false);
        break;

      case FireStage::Humidifying:
        relays.setHumidifier(true);
        if (tempC <= NORMAL_TEMP_C && humidityPct >= TARGET_HUMIDITY_PCT) {
          Serial.println(F("Temp normal, humidity target reached - venting."));
          relays.setHumidifier(false);
          relays.setFan(true);
          stage = FireStage::Venting;
        }
        break;

      case FireStage::Venting:
        relays.setFan(true);
        if (humidityPct <= NORMAL_HUMIDITY_PCT) {
          Serial.println(F("Humidity normal - sequence stable."));
          relays.setFan(false);
          audio.play(VoicePrompt::SystemStable);
          digitalWrite(PIN_STATUS_LED, LOW);
          stage = FireStage::Stable;
        }
        break;

      case FireStage::Stable:
        stage = FireStage::Idle;
        break;
    }
  }
};

#endif // FIRE_PROTECTION_SYSTEM_H
