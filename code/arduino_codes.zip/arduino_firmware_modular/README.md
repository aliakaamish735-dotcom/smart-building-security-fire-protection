# Arduino Firmware — Modular Per-Driver Build (Sensors Project)

This is the **submission-recommended** firmware build: one file per
sensor/actuator driver, matching the course proposal's "modular
structure: one .ino or .cpp/.h file per sensor driver" requirement
literally, rather than grouping multiple sensors per file.

Board: **Arduino Uno R3** + **ESP-01 (ESP8266)** WiFi module. Wiring is
identical to the other firmware builds in this repo — see
`../../docs/SensorsProject_Wiring_Diagram.png` and
`../../docs/SensorsProject_Installation_Guide.pdf`.

## File map

| File | Sensor/actuator | Modality (if applicable) |
|---|---|---|
| `Config.h` | — (pin assignments only) | — |
| `CalibrationConstants.h` | — (thresholds, calibration factors, credentials) | — |
| `EEPROMCalibration.h` | — (optional: persist calibration in EEPROM) | — |
| `TCRT5000_Driver.h` | TCRT5000 IR reflective sensor | **Optical** |
| `PCF8574_KeypadDriver.h` | 4×4 keypad via I2C expander | — (user input) |
| `DHT11_Driver.h` | DHT11 | **Temperature + Humidity** |
| `HX711_Driver.h` | HX711 + load cell | **Force** |
| `FlowSensor_Driver.h` | YF-S201/YF-B1 | **Flow** |
| `ServoDoorLock_Driver.h` | SG90 servo | — (actuator) |
| `DFPlayerAudio_Driver.h` | DFPlayer Mini | — (actuator) |
| `BuzzerAlarm_Driver.h` | Active buzzer | — (actuator) |
| `RelayBank_Driver.h` | 3-channel relay module | — (actuator, 3 channels in 1 file — see note below) |
| `ESP01_WiFi_Driver.h` | ESP-01 | — (communications) |
| `EntrySecuritySystem.h` | — (System 1 algorithm, uses several drivers above) | — |
| `FireProtectionSystem.h` | — (System 2 algorithm, uses several drivers above) | — |
| `sensors_project_modular.ino` | — (setup/loop, object wiring only) | — |

**Why `RelayBank_Driver.h` is one file for 3 channels, not 3 files:**
it's one physical relay module component (bought and wired as a
single 3-channel board), not 3 separate sensor modalities. The
proposal's modularity rule is aimed at sensor *drivers*; treating one
physical actuator module as one driver file is the more natural
reading. If a stricter reading is needed, this file can be trivially
split into `PumpRelay_Driver.h` / `HumidifierRelay_Driver.h` /
`FanRelay_Driver.h` — say the word and I'll split it.

## Two other firmware builds also exist in this repo

- `../arduino_firmware/` — the same logic grouped into 4 files by
  *subsystem* (entry security / fire protection / wifi / main) rather
  than by individual driver. Slightly less granular than this build.
- `../arduino_firmware/sensors_project_single_file.ino` — everything in one
  file, for quick uploads/testing only.

All three builds are functionally identical and share the same
`CalibrationConstants.h` values — pick whichever you're submitting and
keep the others for reference/backup.

## Design notes worth mentioning in your Software Design report section

- Each driver class owns exactly one hardware component's low-level
  access (register reads, pin I/O, library wrapping) and exposes a
  small, purpose-built interface (e.g. `isPersonDetected()`, not raw
  register values) to the two "system" classes above it.
- `EntrySecuritySystem` and `FireProtectionSystem` contain the actual
  algorithm logic from the design document and depend on driver
  *interfaces*, not hardware details — e.g. `FireProtectionSystem`
  doesn't know or care that the flow sensor uses an interrupt
  internally, it just calls `flow.computeFlowLpm(...)`.
- `FlowSensor_Driver.h` uses a static-member/static-ISR pattern because
  `attachInterrupt()` requires a plain function pointer and can't bind
  to a normal class method — documented in that file's header comment.
- `main.ino` (`sensors_project_modular.ino`) intentionally contains no
  sensor-specific logic at all — it only constructs objects and calls
  their public methods, which is what makes this "modular" rather than
  just "reorganized."
