/*
 * RelayBank_Driver.h — Sensors Project
 * Actuators: 3-channel relay module — pump, humidifier, fan
 *
 * All three channels are ACTIVE-LOW (HIGH = off, LOW = energizes the
 * coil) — check your specific relay board's datasheet; if yours is
 * active-HIGH instead, flip ACTIVE_LOW_RELAYS below rather than
 * editing every call site.
 *
 * Grouped as one driver file (rather than 3) because it's one physical
 * relay module component with 3 channels, not 3 separate sensor
 * modalities — see the main README for the modularity rationale.
 *
 * Wiring reminder: relay NO terminals only (never NC), each channel's
 * load side powered from its own external supply (5V pump, humidifier
 * per the voltage-regulation discussion, 12V fan) — never from the
 * Arduino's own 5V rail. See docs/SensorsProject_Wiring_Diagram.png.
 */
#ifndef RELAY_BANK_DRIVER_H
#define RELAY_BANK_DRIVER_H

#include <Arduino.h>
#include "Config.h"

class RelayBankDriver {
public:
  void begin() {
    pinMode(PIN_RELAY_PUMP, OUTPUT);
    pinMode(PIN_RELAY_HUMIDIFIER, OUTPUT);
    pinMode(PIN_RELAY_FAN, OUTPUT);
    // Default OFF at power-up, regardless of active-LOW/HIGH polarity.
    setPump(false);
    setHumidifier(false);
    setFan(false);
  }

  void setPump(bool on)       { write(PIN_RELAY_PUMP, on); }
  void setHumidifier(bool on) { write(PIN_RELAY_HUMIDIFIER, on); }
  void setFan(bool on)        { write(PIN_RELAY_FAN, on); }

private:
  static constexpr bool ACTIVE_LOW_RELAYS = true;

  void write(uint8_t pin, bool on) {
    // "on" always means "relay energized / actuator running" from the
    // caller's point of view. Translate that to the correct electrical
    // level based on the board's actual polarity.
    bool driveHigh = ACTIVE_LOW_RELAYS ? !on : on;
    digitalWrite(pin, driveHigh ? HIGH : LOW);
  }
};

#endif // RELAY_BANK_DRIVER_H
