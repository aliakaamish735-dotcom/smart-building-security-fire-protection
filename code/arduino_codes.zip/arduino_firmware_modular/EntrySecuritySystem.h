/*
 * EntrySecuritySystem.h — Sensors Project
 *
 * Implements System 1 from the algorithm doc, orchestrating the
 * individual drivers (this file contains no direct register/pin
 * access itself — that all lives in the driver files):
 *
 *   IF proximity sensor detects a person near the door:
 *     Play "PLEASE ENTER PASSWORD"
 *     Wait for password input from keypad
 *     IF entered PIN == a registered PIN: open door, reset attempts
 *     ELSE: wrong_attempts++; IF wrong_attempts >= N: alarm
 *
 * PIN checking happens server-side (the dashboard owns the PIN list so
 * PINs can be added/disabled without reflashing firmware). If the
 * server is unreachable, a local fallback counter still enforces
 * lockout — a physical security door must not silently stop
 * protecting itself just because WiFi dropped.
 */
#ifndef ENTRY_SECURITY_SYSTEM_H
#define ENTRY_SECURITY_SYSTEM_H

#include <Arduino.h>
#include "CalibrationConstants.h"
#include "TCRT5000_Driver.h"
#include "PCF8574_KeypadDriver.h"
#include "ServoDoorLock_Driver.h"
#include "DFPlayerAudio_Driver.h"
#include "BuzzerAlarm_Driver.h"
#include "ESP01_WiFi_Driver.h"

class EntrySecuritySystem {
public:
  EntrySecuritySystem(TCRT5000Driver& proximity, PCF8574KeypadDriver& keypad,
                       ServoDoorLockDriver& servo, DFPlayerAudioDriver& audio,
                       BuzzerAlarmDriver& buzzer, ESP01WiFiDriver& wifi)
    : proximity(proximity), keypad(keypad), servo(servo),
      audio(audio), buzzer(buzzer), wifi(wifi) {}

  void begin() {
    proximity.begin();
  }

  // Call every loop() iteration.
  void poll() {
    unsigned long now = millis();
    if (proximity.isPersonDetected() && (now - lastProximityTrigger > PROXIMITY_DEBOUNCE_MS)) {
      lastProximityTrigger = now;
      Serial.println(F("Proximity: person detected, prompting for password."));
      audio.play(VoicePrompt::PleaseEnterPassword);
      pinBuffer = "";
      waitForPinEntry();
    }
  }

  // Dashboard-issued remote unlock (bypasses PIN entry).
  void remoteUnlock() {
    servo.openThenClose();
  }

  // Dashboard-issued disarm: silence buzzer, reset local counter.
  void disarm() {
    buzzer.silence();
    wrongAttempts = 0;
  }

  uint8_t getWrongAttempts() const { return wrongAttempts; }

private:
  TCRT5000Driver& proximity;
  PCF8574KeypadDriver& keypad;
  ServoDoorLockDriver& servo;
  DFPlayerAudioDriver& audio;
  BuzzerAlarmDriver& buzzer;
  ESP01WiFiDriver& wifi;

  String pinBuffer;
  unsigned long lastProximityTrigger = 0;
  uint8_t wrongAttempts = 0;

  void waitForPinEntry() {
    // Blocking wait, matching the algorithm doc's "wait for password
    // input" step. Times out so a person walking away doesn't freeze
    // loop() forever.
    unsigned long start = millis();
    while (millis() - start < KEYPAD_TIMEOUT_MS) {
      char key = keypad.scan();
      if (key != '\0') {
        start = millis(); // reset timeout on each keypress
        if (key == '#') {
          submitPin();
          return;
        } else if (key == '*') {
          pinBuffer = "";
        } else if (key >= '0' && key <= '9') {
          pinBuffer += key;
          if (pinBuffer.length() > 8) pinBuffer = pinBuffer.substring(pinBuffer.length() - 8);
        }
        // 'A','B','C','D' reserved for future use (e.g. admin menu)
      }
    }
    Serial.println(F("Keypad entry timed out."));
  }

  void submitPin() {
    Serial.print(F("Submitting PIN: "));
    Serial.println(pinBuffer);

    PinCheckResult result = wifi.checkPin(pinBuffer);

    if (result == PinCheckResult::ServerUnreachable) {
      // Fail-safe fallback: server normally owns the wrong-attempt
      // count, but a physical door must keep enforcing lockout even
      // if WiFi is down.
      wrongAttempts++;
      Serial.println(F("Server unreachable - using local wrong-attempt fallback."));
      if (wrongAttempts >= MAX_WRONG_ATTEMPTS) {
        audio.play(VoicePrompt::ThiefAttempt);
        buzzer.sound();
      } else {
        audio.play(VoicePrompt::AccessDenied);
      }
    } else if (result == PinCheckResult::Accepted) {
      wrongAttempts = 0;
      audio.play(VoicePrompt::AccessAccepted);
      servo.openThenClose();
    } else if (result == PinCheckResult::ThiefAlarm) {
      wrongAttempts = 0; // server already escalated to ALARM
      audio.play(VoicePrompt::ThiefAttempt);
      buzzer.sound();
      // Door stays locked - do not open the servo.
    } else {
      // Denied, server reachable and already tracking the count.
      audio.play(VoicePrompt::AccessDenied);
    }
    pinBuffer = "";
  }
};

#endif // ENTRY_SECURITY_SYSTEM_H
