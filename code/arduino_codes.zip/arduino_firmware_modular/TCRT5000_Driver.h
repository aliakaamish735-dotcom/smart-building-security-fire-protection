/*
 * TCRT5000_Driver.h — Sensors Project
 * Sensor modality: OPTICAL (IR reflectance / presence detection), interface: analog GPIO
 *
 * Replaces the earlier APDS-9960 (I2C) proximity sensor. The TCRT5000
 * module has an onboard IR LED + phototransistor pair and an LM393
 * comparator with a trim potentiometer for sensitivity.
 *
 * WIRING (see docs/SensorsProject_Wiring_Diagram.png):
 *   VCC -> 5V
 *   GND -> GND
 *   AO  -> Arduino A2 (PIN_PHOTOCELL) — the only wire this driver needs.
 *   DO  -> NOT CONNECTED. This module's own "DO" pin label is a
 *          coincidental name clash with Arduino's D0 pin (USB/Serial
 *          RX) — they are NOT the same thing, and wiring the module's
 *          DO to Arduino's D0 creates a real conflict with Serial
 *          Monitor / uploads. One signal wire (AO) is enough for
 *          presence detection, so DO is left disconnected entirely.
 *
 * This driver reads AO with analogRead() and compares it against
 * PHOTOCELL_THRESHOLD (in CalibrationConstants.h) — same pattern the
 * old APDS-9960 driver used (raw value vs. threshold), just on a 10-bit
 * analog scale (0-1023) instead of an 8-bit I2C proximity register.
 *
 * IMPORTANT — untested detection direction: whether a HIGHER or LOWER
 * analogRead() value means "object/person detected" depends on how
 * your specific module's phototransistor is wired (pull-up vs.
 * pull-down). This driver assumes higher = closer/detected, matching
 * the old APDS-9960 convention. If detection reads backwards on your
 * hardware (triggers when nothing is there, stays quiet when something
 * is), flip the comparison in isPersonDetected() from > to <.
 */
#ifndef TCRT5000_DRIVER_H
#define TCRT5000_DRIVER_H

#include <Arduino.h>
#include "Config.h"
#include "CalibrationConstants.h"

class TCRT5000Driver {
public:
  void begin() {
    pinMode(PIN_PHOTOCELL, INPUT);
  }

  int readRaw() {
    return analogRead(PIN_PHOTOCELL);
  }

  bool isPersonDetected() {
    // If this triggers backwards on your hardware, change > to <.
    return readRaw() > PHOTOCELL_THRESHOLD;
  }
};

#endif // TCRT5000_DRIVER_H
