/*
 * Biological Laboratory Monitor + Security System (Sensors Project)
 * Smart Building Security and Fire Protection System
 * Board: Arduino Uno R3 + ESP-01 (ESP8266) WiFi module
 *
 * SINGLE-FILE BUILD: this is the complete firmware in one .ino file, so
 * you only need to create one sketch (e.g. "sensors_project") and paste this
 * whole file in as sensors_project.ino, then upload. It's organized top to
 * bottom into clearly marked sections:
 *   SECTION 1 - pin config, setup(), loop()
 *   SECTION 2 - entry security: TCRT5000 photocell, keypad (via PCF8574), servo, DFPlayer, buzzer
 *   SECTION 3 - fire protection: DHT11, HX711+load cell, pump, humidifier, fan, flow sensor
 *   SECTION 4 - ESP-01 AT-command WiFi + HTTP POST/GET to the Flask server
 *
 * (A previous 4-file version of this same firmware, split into
 * arduino_firmware.ino / entry_security.ino / fire_protection.ino /
 * wifi_comm.ino, is also available if you prefer separate tabs in the
 * Arduino IDE — both compile to identical behavior.)
 *
 * ---------------------------------------------------------------
 * REQUIRED LIBRARIES (Arduino IDE -> Library Manager):
 *   - "DHT sensor library" by Adafruit (+ "Adafruit Unified Sensor")
 *   - "HX711" by Bogdan Necula (bogde/HX711)
 *   - "Servo" (built into the IDE, no install needed)
 *   - "DFRobotDFPlayerMini" by DFRobot
 *   - "ArduinoJson" by Benoit Blanchon (v6 or v7)
 *   No PCF8574 library needed - the keypad scan is bit-banged directly
 *   over I2C (Wire.h, built in) so there's one less dependency to manage.
 * ---------------------------------------------------------------
 *
 * FULL WIRING — matches Circuit_summary.txt exactly (do not add/omit pins):
 *
 *   Arduino Uno pin map:
 *     D0, D1   -> reserved, left UNCONNECTED (USB serial / CSV debug output)
 *     D2       -> YF-S201/YF-B1 flow sensor, yellow signal wire (interrupt)
 *     D3       -> Active buzzer signal/IN
 *     D4       -> Pump relay IN            (5V pump relay, active-LOW)
 *     D5       -> SG90 servo signal (door lock)
 *     D6       -> DFPlayer Mini TX  (Arduino D6 = RX, receives from DFPlayer)
 *     D7       -> DFPlayer Mini RX, THROUGH A 1kOhm RESISTOR (Arduino D7 = TX)
 *     D8       -> DHT11 DATA
 *     D9       -> Humidifier relay IN (24V humidifier, active-LOW)
 *     D10      -> Fan relay IN (12V fan, active-LOW)
 *     A0       -> HX711 DT/DOUT
 *     A1       -> HX711 SCK/CLK
 *     A2       -> TCRT5000 IR reflective sensor, AO (analog reflectance output)
 *     A4/SDA   -> PCF8574 SDA (keypad expander only)
 *     A5/SCL   -> PCF8574 SCL (keypad expander only)
 *
 *   TCRT5000: VCC->5V, GND->GND, AO->A2. The module's own "DO" pin is
 *     intentionally NOT connected — its label coincidentally matches
 *     Arduino's D0 (USB/Serial RX), which is a completely different
 *     pin; wiring them together would conflict with Serial Monitor
 *     and uploads. One wire (AO) is enough for presence detection.
 *
 *   PCF8574 (I2C addr 0x20): SDA->A4, SCL->A5, VCC->5V, GND->GND,
 *     A0/A1/A2 -> GND (sets address 0x20).
 *     4x4 keypad: P0-P3 = rows R1-R4, P4-P7 = columns C1-C4.
 *
 *   SG90 servo: signal->D5, red->EXTERNAL regulated 5V supply (not the
 *     Arduino 5V pin), brown/black->external supply GND (tied to Arduino GND).
 *
 *   DFPlayer Mini: TX->D6, RX->D7 (through 1k resistor), VCC->5V, GND->GND,
 *     speaker on SPK1/SPK2, microSD card inserted with numbered MP3 tracks.
 *
 *   DHT11: VCC->5V, DATA->D8, GND->GND (add a 4.7k-10k pull-up resistor
 *     between DATA and 5V if using a bare 4-pin DHT11, not needed on the
 *     common 3-pin breakout module which already has one built in).
 *
 *   HX711 + load cell: DT->A0, SCK->A1, VCC->5V, GND->GND. Load cell wires
 *     E+/E-/A+/A- go to the HX711's matching labeled pads (use the load
 *     cell's own wire labels, not color assumptions).
 *
 *   YF-S201/YF-B1 flow sensor: red->5V, black->GND, yellow signal->D2.
 *
 *   Active buzzer (3-pin module): signal/IN->D3, VCC->5V, GND->GND.
 *
 *   3-channel relay module, ALL THREE CHANNELS ACTIVE-LOW:
 *     Control side: CH1(pump) IN->D4, CH2(humidifier) IN->D9, CH3(fan) IN->D10,
 *       VCC->Arduino 5V, GND->Arduino GND.
 *     Power side (use NO terminals only, never NC):
 *       Pump:       external 5V supply(+) -> COM, NO -> pump(+), pump(-) -> supply(-)
 *       Humidifier: 24V adapter(+) -> COM, NO -> humidifier(+), humidifier(-) -> adapter(-)
 *       Fan:        external 12V supply(+) -> COM, NO -> fan(+), fan(-) -> supply(-)
 *
 *   ESP-01 WiFi (via ESP-01 Adapter 3.3V/5V board — NOT direct to 5V):
 *     Adapter VCC->Arduino 5V, Adapter GND->Arduino GND (adapter regulates
 *       3.3V to the ESP-01 internally).
 *     ESP-01 TX -> D11 (Arduino SoftwareSerial RX)
 *     ESP-01 RX -> D12 (Arduino SoftwareSerial TX) -- use a voltage divider
 *       (1k from D12 to ESP RX, 2k from ESP RX to GND) since ESP-01 RX is
 *       3.3V logic and the Uno's D12 outputs 5V.
 *   Status/alarm LED: D13 (with the Uno's onboard 220-1k series resistor
 *     already built into most Uno boards on pin 13, or add your own).
 *
 *   POWER & SAFETY:
 *     - Never power the pump, fan, humidifier, or servo from the Arduino's
 *       5V pin. Use a regulated external 5V supply for servo + pump, 12V
 *       for the fan, and the proper 24V adapter for the humidifier.
 *     - Never connect 12V or 24V to the Arduino 5V rail.
 *     - Tie ALL low-voltage control grounds together: Arduino GND, sensor
 *       GND, PCF8574 GND, HX711 GND, DFPlayer GND, relay control-side GND,
 *       servo external-supply GND, ESP-01 adapter GND.
 *     - Keep pump/fan/humidifier HIGH-power wiring physically separated
 *       from the Arduino's low-voltage signal wiring.
 *
 * Common ground: EVERY module's GND must be tied together, including the
 * external 24V humidifier adapter's ground, or readings and serial comms
 * will be unreliable.
 * ---------------------------------------------------------------
 */

#include <Wire.h>
#include <Servo.h>
#include <DHT.h>
#include <HX711.h>
#include <SoftwareSerial.h>
#include <DFRobotDFPlayerMini.h>
#include <ArduinoJson.h>
#include "CalibrationConstants.h"  // all calibration factors, thresholds, WiFi/device credentials live here now

// USER CONFIG (WIFI_SSID, WIFI_PASSWORD, SERVER_HOST, SERVER_PORT, DEVICE_KEY)
// now lives in CalibrationConstants.h -- edit that file, not this one.

// ----------------------- PIN MAP (matches Circuit_summary.txt) -----------------------
#define PIN_FLOW        2   // YF-S201/YF-B1 flow sensor signal (interrupt)
#define PIN_BUZZER      3   // Active buzzer signal
#define PIN_RELAY_PUMP       4   // Pump relay IN (active-LOW)
#define PIN_SERVO       5   // SG90 servo signal (door lock)
#define PIN_DFPLAYER_RX 6   // Arduino RX <- DFPlayer TX
#define PIN_DFPLAYER_TX 7   // Arduino TX -> DFPlayer RX (through 1k resistor)
#define PIN_DHT         8   // DHT11 data
#define PIN_RELAY_HUMIDIFIER 9    // Humidifier relay IN (active-LOW)
#define PIN_RELAY_FAN        10   // Fan relay IN (active-LOW)
#define PIN_ESP_RX      11  // Arduino SoftwareSerial RX <- ESP-01 TX
#define PIN_ESP_TX      12  // Arduino SoftwareSerial TX -> ESP-01 RX (use voltage divider!)
#define PIN_STATUS_LED  13
#define PIN_HX711_DT    A0
#define PIN_HX711_SCK   A1
#define PIN_PHOTOCELL   A2   // TCRT5000 IR reflective sensor (analog reflectance output)
// A4 (SDA) / A5 (SCL) used implicitly by Wire.h for the PCF8574 keypad expander

#define PCF8574_ADDR    0x20

#define DHTTYPE DHT11
// ---------------------------------------------------------

// ----------------------- SHARED OBJECTS -----------------------
DHT dht(PIN_DHT, DHTTYPE);
HX711 scale;
Servo doorServo;

SoftwareSerial dfPlayerSerial(PIN_DFPLAYER_TX, PIN_DFPLAYER_RX); // (RX, TX) for talking to DFPlayer
DFRobotDFPlayerMini dfPlayer;

SoftwareSerial espSerial(PIN_ESP_RX, PIN_ESP_TX); // (RX, TX) for talking to ESP-01

// ----------------------- SHARED STATE -----------------------
volatile unsigned long flowPulseCount = 0;
float currentFlowLpm = 0.0;
// YF-S201/YF-B1-style calibration: ~7.5 pulses/sec per L/min (typical
// datasheet value). Re-derive this during your 3-point calibration for
// the report and update FLOW_CALIBRATION_FACTOR below.
// FLOW_CALIBRATION_FACTOR now comes from CalibrationConstants.h

int wrongAttempts = 0;
// MAX_WRONG_ATTEMPTS now comes from CalibrationConstants.h

enum FireStage { IDLE, FIRE_DETECTED, FILLING_TANK, BLOCKED, HUMIDIFYING, VENTING, STABLE };
enum KeypadResult { PIN_ACCEPTED, PIN_DENIED, PIN_THIEF_ALARM, PIN_SERVER_UNREACHABLE };
FireStage fireStage = IDLE;

float lastTempC = NAN;
float lastHumidity = NAN;
float lastWeightG = 0.0;

// FIRE_THRESHOLD_C now comes from CalibrationConstants.h
// NORMAL_TEMP_C now comes from CalibrationConstants.h
// TARGET_WEIGHT_G now comes from CalibrationConstants.h
// TARGET_HUMIDITY_PCT now comes from CalibrationConstants.h
// NORMAL_HUMIDITY_PCT now comes from CalibrationConstants.h

unsigned long lastSensorPost = 0;
// SENSOR_POST_INTERVAL now comes from CalibrationConstants.h

unsigned long lastCommandPoll = 0;
// COMMAND_POLL_INTERVAL now comes from CalibrationConstants.h

void flowPulseISR(); // defined in fire_protection.ino

// ---------------------------------------------------------
void setup() {
  Serial.begin(9600);
  Serial.println(F("\nBiological Laboratory Monitor - Arduino firmware starting..."));

  Wire.begin();

  pinMode(PIN_BUZZER, OUTPUT);
  digitalWrite(PIN_BUZZER, LOW);

  pinMode(PIN_RELAY_PUMP, OUTPUT);
  pinMode(PIN_RELAY_HUMIDIFIER, OUTPUT);
  pinMode(PIN_RELAY_FAN, OUTPUT);
  // Relay modules are active-LOW: HIGH = off, LOW = energizes the coil.
  digitalWrite(PIN_RELAY_PUMP, HIGH);
  digitalWrite(PIN_RELAY_HUMIDIFIER, HIGH);
  digitalWrite(PIN_RELAY_FAN, HIGH);

  pinMode(PIN_STATUS_LED, OUTPUT);

  pinMode(PIN_FLOW, INPUT_PULLUP);
  attachInterrupt(digitalPinToInterrupt(PIN_FLOW), flowPulseISR, FALLING);

  dht.begin();

  scale.begin(PIN_HX711_DT, PIN_HX711_SCK);
  // Replace this with your real calibration factor from the load cell
  // calibration procedure (known weight / raw reading ratio).
  scale.set_scale(LOADCELL_SCALE_FACTOR);  // from CalibrationConstants.h
  scale.tare(); // zero the scale with an empty tank

  doorServo.attach(PIN_SERVO);
  doorServo.write(0); // 0 degrees = closed position, adjust to your mechanism

  dfPlayerSerial.begin(9600);
  if (dfPlayer.begin(dfPlayerSerial)) {
    dfPlayer.volume(20); // 0-30
    Serial.println(F("DFPlayer Mini ready."));
  } else {
    Serial.println(F("WARNING: DFPlayer Mini not detected. Check wiring/SD card."));
  }

  setupKeypadExpander(); // in entry_security.ino
  setupApds9960();       // in entry_security.ino

  espSerial.begin(9600);
  setupWifi(); // in wifi_comm.ino

  // CSV header — everything after this point that starts with "DATA,"
  // is one row of this table. Capture Serial Monitor output and strip
  // non-"DATA," lines to get a clean CSV for Excel/MATLAB/Python.
  Serial.println(F("CSV_HEADER,millis_ts,temp_c,humidity_pct,tank_weight_g,flow_lpm,proximity,fire_stage,wrong_attempts"));
}

// ---------------------------------------------------------
void printCsvRow() {
  Serial.print(F("DATA,"));
  Serial.print(millis());
  Serial.print(',');
  Serial.print(isnan(lastTempC) ? -1.0 : lastTempC, 2);
  Serial.print(',');
  Serial.print(isnan(lastHumidity) ? -1.0 : lastHumidity, 2);
  Serial.print(',');
  Serial.print(lastWeightG, 1);
  Serial.print(',');
  Serial.print(currentFlowLpm, 3);
  Serial.print(',');
  Serial.print(readProximity() > PHOTOCELL_THRESHOLD ? 1 : 0);
  Serial.print(',');
  Serial.print(fireStageName());
  Serial.print(',');
  Serial.println(wrongAttempts);
}

// ---------------------------------------------------------
void loop() {
  pollProximityAndKeypad(); // in entry_security.ino, handles the entry algorithm

  unsigned long now = millis();

  if (now - lastSensorPost >= SENSOR_POST_INTERVAL) {
    lastSensorPost = now;
    runFireProtectionStep(); // in fire_protection.ino, advances the local state machine
    Serial.print(F("Fire stage: "));
    Serial.println(fireStageName());
    printCsvRow();            // machine-readable CSV row for offline analysis/plotting
    postSensorReadings();    // in wifi_comm.ino, also returns server-confirmed fire state
  }

  if (now - lastCommandPoll >= COMMAND_POLL_INTERVAL) {
    lastCommandPoll = now;
    pollDashboardCommands(); // in wifi_comm.ino
  }
}

// ======================================================================
// SECTION 2 — ENTRY SECURITY (TCRT5000 photocell, PCF8574 keypad, servo, DFPlayer, buzzer)
// ======================================================================
/*
Implements System 1 from the algorithm doc:
  IF proximity sensor detects a person near the door:
    Play "PLEASE ENTER PASSWORD"
    Wait for password input from keypad
    IF entered password == stored password: open door, reset attempts
    ELSE: increase wrong attempts; IF wrong attempts >= N: alarm

Proximity is read from a TCRT5000 IR reflective sensor: a single
analog wire (AO -> A2), no library or I2C involved at all. This
replaced an earlier APDS-9960 (I2C) design — see the "TCRT5000 IR
reflective sensor" section below for the current implementation. The
keypad is wired to a PCF8574 I2C I/O expander (address 0x20), not
direct Arduino pins.

DFPlayer audio tracks (numbered MP3s on the microSD card):
  1 PLEASE ENTER PASSWORD          5 HIGH TEMPERATURE DETECTED
  2 ACCESS ACCEPTED                6 PIPE BLOCKAGE DETECTED
  3 ACCESS DENIED                  7 SYSTEM STABLE
  4 ACCESS DENIED, THIEF ATTEMPT
*/

// ----------------------- TCRT5000 IR reflective sensor -----------------------
// Replaces the earlier APDS-9960 (I2C). Single-wire analog connection:
//   VCC -> 5V, GND -> GND, AO -> Arduino A2 (PIN_PHOTOCELL)
// The module's own "DO" pin is intentionally left disconnected — its
// name coincidentally matches Arduino's D0 (USB/Serial RX) but is NOT
// the same pin, and wiring it there would conflict with Serial
// Monitor/uploads. One analog wire (AO) is enough for presence detection.
//
// PHOTOCELL_THRESHOLD comes from CalibrationConstants.h (0-1023 scale).

void setupApds9960() {
  // Function name kept for continuity with the rest of this file's
  // call sites; TCRT5000 needs no I2C setup, just pin mode.
  pinMode(PIN_PHOTOCELL, INPUT);
  Serial.println(F("TCRT5000 photocell ready on A2 (analog)."));
}

int readProximity() {
  // NOTE: untested detection direction on your specific module — if
  // this triggers backwards (detects when nothing is there), swap
  // the comparison direction wherever PHOTOCELL_THRESHOLD is used.
  return analogRead(PIN_PHOTOCELL); // raw 0-1023, matches PHOTOCELL_THRESHOLD's scale directly
}

// ----------------------- PCF8574 keypad scan -----------------------
// Rows P0-P3 driven as outputs (one LOW at a time), columns P4-P7 read as
// inputs with pull-ups. Standard 4x4 matrix scan, just bit-banged over I2C
// instead of native digitalRead/digitalWrite.

const char KEYPAD_MAP[4][4] = {
  {'1', '2', '3', 'A'},
  {'4', '5', '6', 'B'},
  {'7', '8', '9', 'C'},
  {'*', '0', '#', 'D'}
};

void pcf8574_write(uint8_t value) {
  Wire.beginTransmission(PCF8574_ADDR);
  Wire.write(value);
  Wire.endTransmission();
}

uint8_t pcf8574_read() {
  Wire.requestFrom((int)PCF8574_ADDR, 1);
  if (Wire.available()) return Wire.read();
  return 0xFF;
}

void setupKeypadExpander() {
  // PCF8574 quasi-bidirectional I/O: writing 1 to a pin makes it a weak-pullup
  // input; writing 0 drives it low. Initialize columns (P4-P7) high (input
  // mode) and rows (P0-P3) high too (idle); we'll pull one row low at a time
  // during scanning.
  pcf8574_write(0xFF);
}

char scanKeypad() {
  for (uint8_t row = 0; row < 4; row++) {
    // Drive only this row low, keep all other rows + all columns high (input/pullup)
    uint8_t rowMask = ~(1 << row) & 0x0F;       // rows = P0-P3
    uint8_t output = (rowMask & 0x0F) | 0xF0;    // columns P4-P7 stay high
    pcf8574_write(output);
    delayMicroseconds(50); // let the line settle

    uint8_t colState = pcf8574_read() >> 4;      // columns are the upper nibble
    for (uint8_t col = 0; col < 4; col++) {
      if (!(colState & (1 << col))) {
        delay(15); // debounce the initial contact bounce
        char pressedKey = KEYPAD_MAP[row][col];

        // Wait here until the key is actually released. Without this,
        // a single physical press (100-300ms+) gets detected again
        // every ~15ms for as long as the finger is still on the key,
        // corrupting every PIN entry with repeated digits.
        while (true) {
          pcf8574_write(output);
          delayMicroseconds(50);
          uint8_t stillPressed = (pcf8574_read() >> 4) & (1 << col);
          if (stillPressed) break; // bit reads 1 again = released
          delay(10);
        }
        delay(20); // extra debounce after release

        pcf8574_write(0xFF);
        return pressedKey;
      }
    }
  }
  pcf8574_write(0xFF);
  return '\0'; // no key pressed
}

// ----------------------- Entry security state -----------------------
String pinBuffer = "";
unsigned long lastProximityTrigger = 0;
// PROXIMITY_DEBOUNCE_MS now comes from CalibrationConstants.h

void openDoorServo() {
  doorServo.write(90);  // open position, adjust to your mechanism
  delay(DOOR_OPEN_MS);   // "Wait 5 seconds" per the algorithm doc
  doorServo.write(0);    // close position
}

void pollProximityAndKeypad() {
  int prox = readProximity();
  bool personDetected = prox > PHOTOCELL_THRESHOLD;

  unsigned long now = millis();
  if (personDetected && (now - lastProximityTrigger > PROXIMITY_DEBOUNCE_MS)) {
    lastProximityTrigger = now;
    Serial.println(F("Proximity: person detected, prompting for password."));
    dfPlayer.play(1); // "PLEASE ENTER PASSWORD"
    pinBuffer = "";
    waitForPinEntry();
  }
}

void waitForPinEntry() {
  // Blocking wait for keypad input, matching the algorithm doc's
  // "Wait for password input from keypad" step. Times out after 15s so a
  // person walking away doesn't freeze the whole loop() forever.
  unsigned long start = millis();
  const unsigned long TIMEOUT_MS = KEYPAD_TIMEOUT_MS; // from CalibrationConstants.h

  while (millis() - start < TIMEOUT_MS) {
    char key = scanKeypad();
    if (key != '\0') {
      start = millis(); // reset timeout on each keypress
      if (key == '#') {
        submitPin();
        return;
      } else if (key == '*') {
        pinBuffer = ""; // clear entry
      } else if (key >= '0' && key <= '9') {
        pinBuffer += key;
        if (pinBuffer.length() > 8) pinBuffer = pinBuffer.substring(pinBuffer.length() - 8);
      }
      // 'A','B','C','D' reserved for future use (e.g. admin menu), ignored here
    }
  }
  Serial.println(F("Keypad entry timed out."));
}

void submitPin() {
  Serial.print(F("Submitting PIN: "));
  Serial.println(pinBuffer);

  KeypadResult result = checkPinWithServer(pinBuffer); // in wifi_comm.ino

  if (result == PIN_SERVER_UNREACHABLE) {
    // Fail-safe fallback: the server normally owns the wrong-attempt count
    // and PIN list, but if WiFi is down this is a physical security door
    // and must not silently stop enforcing lockout. Count locally instead.
    wrongAttempts++;
    Serial.println(F("Server unreachable - using local wrong-attempt fallback."));
    if (wrongAttempts >= MAX_WRONG_ATTEMPTS) {
      dfPlayer.play(4); // "ACCESS DENIED, THIEF ATTEMPT"
      soundBuzzerAlarm();
    } else {
      dfPlayer.play(3); // "ACCESS DENIED"
    }
    pinBuffer = "";
    return;
  }

  if (result == PIN_ACCEPTED) {
    wrongAttempts = 0;
    dfPlayer.play(2); // "ACCESS ACCEPTED"
    openDoorServo();
  } else if (result == PIN_THIEF_ALARM) {
    wrongAttempts = 0; // server already escalated to ALARM; local counter resets with it
    dfPlayer.play(4); // "ACCESS DENIED, THIEF ATTEMPT"
    soundBuzzerAlarm();
    // Door stays locked - do not call openDoorServo()
  } else {
    // PIN_DENIED (server reachable, PIN just wrong - server is tracking the count)
    dfPlayer.play(3); // "ACCESS DENIED"
  }
  pinBuffer = "";
}

void soundBuzzerAlarm() {
  digitalWrite(PIN_BUZZER, HIGH);
}

void silenceBuzzer() {
  digitalWrite(PIN_BUZZER, LOW);
}

// ======================================================================
// SECTION 3 — FIRE PROTECTION (DHT11, HX711+load cell, pump/humidifier/fan, flow sensor)
// ======================================================================
/*
Implements System 2 from the algorithm doc:
  Read temp/humidity continuously
  IF temp > FIRE_THRESHOLD: alarm LED, pump ON
    WHILE tank weight < TARGET_WEIGHT: read load cell
      IF flow == 0: pump OFF, buzzer, "PIPE BLOCKAGE DETECTED", stop sequence
    pump OFF, humidifier ON
    WHILE temp > NORMAL_TEMPERATURE: keep humidifier ON
    IF temp <= NORMAL_TEMPERATURE AND humidity >= TARGET_HUMIDITY:
      humidifier OFF, fan ON
      WHILE humidity > NORMAL_HUMIDITY: keep fan ON
      fan OFF, "SYSTEM STABLE"

Runs LOCALLY on the Arduino (not waiting on the server) so the
fire-suppression sequence keeps working even if WiFi/the dashboard is
unreachable — this is a physical safety system, and a network hiccup
must never block water reaching the fire.
*/

void flowPulseISR() {
  flowPulseCount++;
}

float readTankWeightGrams() {
  if (scale.is_ready()) {
    return scale.get_units(3); // average of 3 reads, in grams (after set_scale calibration)
  }
  return lastWeightG; // HX711 not ready this tick, reuse last good value
}

float computeFlowLpm() {
  noInterrupts();
  unsigned long pulses = flowPulseCount;
  flowPulseCount = 0;
  interrupts();
  // pulses counted over SENSOR_POST_INTERVAL (5000ms) -> convert to L/min
  float pulsesPerSecond = pulses / (SENSOR_POST_INTERVAL / 1000.0);
  return pulsesPerSecond / FLOW_CALIBRATION_FACTOR;
}

void setRelay(int pin, bool on) {
  // Active-LOW relay assumption (see setup() comment in arduino_firmware.ino)
  digitalWrite(pin, on ? LOW : HIGH);
}

/*
 * Advances the local fire-protection state machine by one step, using
 * the most recent DHT11/HX711/flow readings. Called once per
 * SENSOR_POST_INTERVAL from loop(), same cadence as the readings
 * themselves so the sequence can't race ahead of real sensor data.
 */
void runFireProtectionStep() {
  lastTempC = dht.readTemperature();
  lastHumidity = dht.readHumidity();
  lastWeightG = readTankWeightGrams();
  currentFlowLpm = computeFlowLpm();

  if (isnan(lastTempC) || isnan(lastHumidity)) {
    Serial.println(F("WARNING: DHT11 read failed this cycle, skipping fire-sequence step."));
    return;
  }

  switch (fireStage) {

    case IDLE:
      if (lastTempC > FIRE_THRESHOLD_C) {
        Serial.println(F("FIRE DETECTED - starting suppression sequence."));
        dfPlayer.play(5); // "HIGH TEMPERATURE DETECTED"
        digitalWrite(PIN_STATUS_LED, HIGH); // alarm LED
        fireStage = FIRE_DETECTED;
      }
      break;

    case FIRE_DETECTED:
      setRelay(PIN_RELAY_PUMP, true);
      fireStage = FILLING_TANK;
      break;

    case FILLING_TANK:
      setRelay(PIN_RELAY_PUMP, true);
      if (currentFlowLpm <= 0.05) {
        Serial.println(F("PIPE BLOCKAGE - stopping pump, halting sequence."));
        setRelay(PIN_RELAY_PUMP, false);
        dfPlayer.play(6); // "PIPE BLOCKAGE DETECTED"
        soundBuzzerAlarm();
        fireStage = BLOCKED;
      } else if (lastWeightG >= TARGET_WEIGHT_G) {
        Serial.println(F("Tank full - switching to humidifier."));
        setRelay(PIN_RELAY_PUMP, false);
        setRelay(PIN_RELAY_HUMIDIFIER, true);
        fireStage = HUMIDIFYING;
      }
      break;

    case BLOCKED:
      // Stays here until the dashboard issues a clear_blockage command
      // (handled in wifi_comm.ino's pollDashboardCommands) once someone
      // has physically fixed the pipe - a network-only reset would be
      // unsafe for a real blockage.
      setRelay(PIN_RELAY_PUMP, false);
      break;

    case HUMIDIFYING:
      setRelay(PIN_RELAY_HUMIDIFIER, true);
      if (lastTempC <= NORMAL_TEMP_C && lastHumidity >= TARGET_HUMIDITY_PCT) {
        Serial.println(F("Temp normal, humidity target reached - venting."));
        setRelay(PIN_RELAY_HUMIDIFIER, false);
        setRelay(PIN_RELAY_FAN, true);
        fireStage = VENTING;
      }
      break;

    case VENTING:
      setRelay(PIN_RELAY_FAN, true);
      if (lastHumidity <= NORMAL_HUMIDITY_PCT) {
        Serial.println(F("Humidity normal - sequence stable."));
        setRelay(PIN_RELAY_FAN, false);
        dfPlayer.play(7); // "SYSTEM STABLE"
        digitalWrite(PIN_STATUS_LED, LOW);
        fireStage = STABLE;
      }
      break;

    case STABLE:
      fireStage = IDLE;
      break;
  }
}

const char* fireStageName() {
  switch (fireStage) {
    case IDLE: return "IDLE";
    case FIRE_DETECTED: return "FIRE_DETECTED";
    case FILLING_TANK: return "FILLING_TANK";
    case BLOCKED: return "BLOCKED";
    case HUMIDIFYING: return "HUMIDIFYING";
    case VENTING: return "VENTING";
    case STABLE: return "STABLE";
    default: return "UNKNOWN";
  }
}

// ======================================================================
// SECTION 4 — ESP-01 WIFI (AT commands, HTTP POST/GET to the Flask server)
// ======================================================================
/*
The ESP-01 has no native Arduino HTTP library the way an ESP32 does —
it's just a WiFi modem you talk to over serial using AT commands. This
section wraps that into postSensorReadings()/checkPinWithServer()/
pollDashboardCommands() helpers so the rest of the sketch doesn't need
to know AT-command details.

IMPORTANT: ESP-01 firmware varies. This assumes a standard Espressif
"AT" firmware (most ESP-01 modules ship with this). If yours responds
unexpectedly, re-flash it with the official AT firmware from Espressif.

ESP-01 RX is 3.3V logic. The Arduino's D12 (TX to the ESP-01) outputs
5V — use a voltage divider (1k from D12 to ESP RX, 2k from ESP RX to
GND) or a proper logic-level shifter.
*/

bool espSendCommand(const String& cmd, const String& expectedEnd, unsigned long timeoutMs) {
  espSerial.println(cmd);
  unsigned long start = millis();
  String response = "";
  while (millis() - start < timeoutMs) {
    while (espSerial.available()) {
      char c = espSerial.read();
      response += c;
      if (response.indexOf(expectedEnd) != -1) {
        return true;
      }
    }
  }
  Serial.print(F("ESP-01 command timed out: "));
  Serial.println(cmd);
  Serial.print(F("  partial response: "));
  Serial.println(response);
  return false;
}

void setupWifi() {
  Serial.println(F("Initializing ESP-01..."));
  espSendCommand("AT", "OK", 2000);
  espSendCommand("AT+CWMODE=1", "OK", 2000);          // station mode

  String joinCmd = "AT+CWJAP=\"" + String(WIFI_SSID) + "\",\"" + String(WIFI_PASSWORD) + "\"";
  Serial.println(F("Connecting to WiFi (this can take 10-20s)..."));
  bool joined = espSendCommand(joinCmd, "OK", 20000);

  if (joined) {
    Serial.println(F("ESP-01 WiFi connected."));
  } else {
    Serial.println(F("WARNING: ESP-01 WiFi join failed. Will retry on next post."));
  }

  espSendCommand("AT+CIPMUX=0", "OK", 2000); // single connection mode, simplest for our use case
}

void ensureWifi() {
  // Quick check: if AT+CWJAP? comes back without an SSID, rejoin.
  espSerial.println("AT+CWJAP?");
  unsigned long start = millis();
  String response = "";
  while (millis() - start < 3000) {
    while (espSerial.available()) response += (char)espSerial.read();
  }
  if (response.indexOf(WIFI_SSID) == -1) {
    Serial.println(F("WiFi not connected, reconnecting..."));
    setupWifi();
  }
}

/*
 * Opens a TCP connection to the Flask server, sends a raw HTTP request,
 * and returns the response body (after the blank line that ends HTTP
 * headers). Used by both postJsonToServer() and getFromServer() below.
 */
String espHttpRequest(const String& httpRequest) {
  ensureWifi();

  String startCmd = "AT+CIPSTART=\"TCP\",\"" + String(SERVER_HOST) + "\"," + String(SERVER_PORT);
  if (!espSendCommand(startCmd, "OK", 5000)) {
    return "";
  }

  String sendCmd = "AT+CIPSEND=" + String(httpRequest.length());
  espSerial.println(sendCmd);
  delay(100);
  espSerial.print(httpRequest);

  unsigned long start = millis();
  String response = "";
  while (millis() - start < 5000) {
    while (espSerial.available()) {
      response += (char)espSerial.read();
    }
    if (response.indexOf("CLOSED") != -1) break;
  }

  espSendCommand("AT+CIPCLOSE", "OK", 2000);

  int bodyStart = response.indexOf("\r\n\r\n");
  if (bodyStart != -1) {
    return response.substring(bodyStart + 4);
  }
  return response;
}

String buildPostRequest(const String& path, const String& jsonBody) {
  String req = "POST " + path + " HTTP/1.1\r\n";
  req += "Host: " + String(SERVER_HOST) + "\r\n";
  req += "Content-Type: application/json\r\n";
  req += "X-Device-Key: " + String(DEVICE_KEY) + "\r\n";
  req += "Content-Length: " + String(jsonBody.length()) + "\r\n";
  req += "Connection: close\r\n\r\n";
  req += jsonBody;
  return req;
}

String buildGetRequest(const String& path) {
  String req = "GET " + path + " HTTP/1.1\r\n";
  req += "Host: " + String(SERVER_HOST) + "\r\n";
  req += "Connection: close\r\n\r\n";
  return req;
}

// ---------------------------------------------------------
void postSensorReadings() {
  StaticJsonDocument<256> doc;
  if (!isnan(lastTempC)) doc["temp_c"] = lastTempC;
  if (!isnan(lastHumidity)) doc["humidity_pct"] = lastHumidity;
  doc["tank_weight_g"] = lastWeightG;
  doc["flow_lpm"] = currentFlowLpm;
  doc["proximity_detected"] = (readProximity() > PHOTOCELL_THRESHOLD);

  String jsonBody;
  serializeJson(doc, jsonBody);

  String request = buildPostRequest("/api/ingest/sensors", jsonBody);
  String response = espHttpRequest(request);

  if (response.length() == 0) {
    Serial.println(F("Sensor post failed (no response) - fire sequence continues locally regardless."));
  } else {
    Serial.print(F("Sensor post response: "));
    Serial.println(response);
  }
}

KeypadResult checkPinWithServer(const String& pin) {
  StaticJsonDocument<64> doc;
  doc["pin"] = pin;
  String jsonBody;
  serializeJson(doc, jsonBody);

  String request = buildPostRequest("/api/ingest/keypad", jsonBody);
  String response = espHttpRequest(request);

  if (response.length() == 0) {
    Serial.println(F("Keypad check: server unreachable, using local fallback lockout."));
    return PIN_SERVER_UNREACHABLE;
  }

  StaticJsonDocument<256> respDoc;
  DeserializationError err = deserializeJson(respDoc, response);
  if (err) {
    Serial.println(F("Keypad check: could not parse server response."));
    return PIN_SERVER_UNREACHABLE;
  }

  const char* result = respDoc["result"] | "denied";
  if (strcmp(result, "accepted") == 0) return PIN_ACCEPTED;
  if (strcmp(result, "thief_attempt") == 0) return PIN_THIEF_ALARM;
  return PIN_DENIED;
}

void pollDashboardCommands() {
  String request = buildGetRequest("/api/command?key=" + String(DEVICE_KEY));
  String response = espHttpRequest(request);
  if (response.length() == 0) return;

  StaticJsonDocument<128> doc;
  if (deserializeJson(doc, response)) return;

  const char* cmd = doc["command"] | "";
  if (strcmp(cmd, "unlock") == 0) {
    openDoorServo();
  } else if (strcmp(cmd, "disarm") == 0) {
    silenceBuzzer();
    wrongAttempts = 0;
  } else if (strcmp(cmd, "clear_blockage") == 0 && fireStage == BLOCKED) {
    Serial.println(F("Blockage cleared from dashboard - resetting fire sequence."));
    silenceBuzzer();
    fireStage = IDLE;
    digitalWrite(PIN_STATUS_LED, LOW);
  }
}
