/*
 * Sensors Project — Biological Laboratory Monitor + Security System
 * Smart Building Security and Fire Protection System
 * Board: Arduino Uno R3 + ESP-01 (ESP8266) WiFi module
 *
 * MODULAR BUILD — one file per sensor/actuator driver, per the course
 * proposal's firmware requirement. This main .ino only does three
 * things: construct the driver/system objects, call begin() on
 * everything in setup(), and coordinate the two systems + CSV logging
 * + dashboard command dispatch in loop(). All sensor-specific logic
 * lives in the individual driver files listed below.
 *
 * File map:
 *   Config.h                    - pin assignments only
 *   CalibrationConstants.h      - all thresholds/calibration/credentials
 *   EEPROMCalibration.h         - optional: persist calibration in EEPROM
 *   TCRT5000_Driver.h            - optical / proximity sensor
 *   PCF8574_KeypadDriver.h      - 4x4 keypad via I2C expander
 *   DHT11_Driver.h              - temperature + humidity
 *   HX711_Driver.h              - force / load cell
 *   FlowSensor_Driver.h         - flow sensor
 *   ServoDoorLock_Driver.h      - door lock actuator
 *   DFPlayerAudio_Driver.h      - voice prompt actuator
 *   BuzzerAlarm_Driver.h        - alarm actuator
 *   RelayBank_Driver.h          - pump/humidifier/fan relay actuators
 *   ESP01_WiFi_Driver.h         - WiFi + HTTP to the Flask dashboard
 *   EntrySecuritySystem.h       - System 1 algorithm (uses several drivers above)
 *   FireProtectionSystem.h      - System 2 algorithm (uses several drivers above)
 *   sensors_project_modular.ino      - this file: setup(), loop(), object wiring
 *
 * REQUIRED LIBRARIES (Arduino IDE -> Library Manager):
 *   DHT sensor library (Adafruit) + Adafruit Unified Sensor, HX711
 *   (Bogdan Necula), Servo (built-in), DFRobotDFPlayerMini (DFRobot),
 *   ArduinoJson (Benoit Blanchon, v6 or v7). Wire, EEPROM,
 *   SoftwareSerial are all Arduino-core built-ins. No PCF8574 library
 *   needed — bit-banged directly to keep the I2C bus simple (now used
 *   only by the PCF8574, since the TCRT5000 photocell is analog).
 *
 * See docs/SensorsProject_Installation_Guide.pdf for wiring, calibration,
 * and upload instructions. Edit CalibrationConstants.h before
 * uploading (WiFi credentials, server IP, device key, calibration
 * factors) — nothing in this file should normally need editing.
 */

#include <Wire.h>
#include "Config.h"
#include "CalibrationConstants.h"

#include "TCRT5000_Driver.h"
#include "PCF8574_KeypadDriver.h"
#include "DHT11_Driver.h"
#include "HX711_Driver.h"
#include "FlowSensor_Driver.h"
#include "ServoDoorLock_Driver.h"
#include "DFPlayerAudio_Driver.h"
#include "BuzzerAlarm_Driver.h"
#include "RelayBank_Driver.h"
#include "ESP01_WiFi_Driver.h"

#include "EntrySecuritySystem.h"
#include "FireProtectionSystem.h"

// ----------------------- Driver instances -----------------------
TCRT5000Driver proximityDriver;
PCF8574KeypadDriver keypadDriver;
DHT11Driver dhtDriver;
HX711Driver loadCellDriver;
FlowSensorDriver flowDriver;
ServoDoorLockDriver servoDriver;
DFPlayerAudioDriver audioDriver;
BuzzerAlarmDriver buzzerDriver;
RelayBankDriver relayDriver;
ESP01WiFiDriver wifiDriver;

// ----------------------- System instances (own the algorithms) -----------------------
EntrySecuritySystem entrySecurity(proximityDriver, keypadDriver, servoDriver, audioDriver, buzzerDriver, wifiDriver);
FireProtectionSystem fireProtection(dhtDriver, loadCellDriver, flowDriver, relayDriver, audioDriver, buzzerDriver);

// ----------------------- Timing -----------------------
unsigned long lastSensorPost = 0;
unsigned long lastCommandPoll = 0;

void setup() {
  Serial.begin(9600);
  Serial.println(F("\nSensors Project - modular firmware starting..."));

  Wire.begin();

  buzzerDriver.begin();
  servoDriver.begin();
  audioDriver.begin();
  keypadDriver.begin();

  entrySecurity.begin();     // brings up the proximity sensor
  fireProtection.begin();    // brings up DHT11, HX711, flow sensor, relays, status LED

  wifiDriver.begin();

  // CSV header — everything after this that starts with "DATA," is one
  // row of this table (see /data/README.md for the matching schema).
  Serial.println(F("CSV_HEADER,millis_ts,temp_c,humidity_pct,tank_weight_g,flow_lpm,proximity,fire_stage,wrong_attempts"));
}

void loop() {
  entrySecurity.poll(); // handles proximity -> PIN -> door/alarm, may block briefly on keypad entry

  unsigned long now = millis();

  if (now - lastSensorPost >= SENSOR_POST_INTERVAL) {
    lastSensorPost = now;
    bool dhtOk = fireProtection.step(); // advances the local fire-protection state machine

    bool proximityNow = proximityDriver.isPersonDetected();
    printCsvRow(proximityNow);

    SensorPayload payload;
    payload.tempC = fireProtection.getLastTempC();
    payload.humidityPct = fireProtection.getLastHumidityPct();
    payload.tempValid = dhtOk;
    payload.humidityValid = dhtOk;
    payload.tankWeightG = fireProtection.getLastWeightG();
    payload.flowLpm = fireProtection.getLastFlowLpm();
    payload.proximityDetected = proximityNow;
    wifiDriver.postSensorReadings(payload);
  }

  if (now - lastCommandPoll >= COMMAND_POLL_INTERVAL) {
    lastCommandPoll = now;
    dispatchCommand(wifiDriver.pollCommand());
  }
}

void dispatchCommand(DashboardCommand cmd) {
  switch (cmd) {
    case DashboardCommand::Unlock:
      entrySecurity.remoteUnlock();
      break;
    case DashboardCommand::Disarm:
      entrySecurity.disarm();
      break;
    case DashboardCommand::ClearBlockage:
      fireProtection.clearBlockage();
      break;
    case DashboardCommand::None:
    default:
      break;
  }
}

void printCsvRow(bool proximityNow) {
  Serial.print(F("DATA,"));
  Serial.print(millis());
  Serial.print(',');
  Serial.print(fireProtection.getLastTempC(), 2);
  Serial.print(',');
  Serial.print(fireProtection.getLastHumidityPct(), 2);
  Serial.print(',');
  Serial.print(fireProtection.getLastWeightG(), 1);
  Serial.print(',');
  Serial.print(fireProtection.getLastFlowLpm(), 3);
  Serial.print(',');
  Serial.print(proximityNow ? 1 : 0);
  Serial.print(',');
  Serial.print(fireProtection.stageName());
  Serial.print(',');
  Serial.println(entrySecurity.getWrongAttempts());
}
