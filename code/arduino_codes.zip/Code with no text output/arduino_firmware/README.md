# Arduino Firmware — Smart Building Security and Fire Protection System (Sensors Project)

Board: **Arduino Uno R3** (fully standalone — no WiFi, no ESP-01, no server).

> **All calibration factors, thresholds, and the door PIN now live in
> `CalibrationConstants.h`** — edit that one file, not the pin/logic
> files below. An optional `EEPROMCalibration.h` module is also
> included if you want calibration factors to survive a re-flash (see
> the comment header in that file).

This sketch is split across 3 `.ino` files + `CalibrationConstants.h`
in this folder. Open `arduino_firmware.ino` in the Arduino IDE — the
other files (`entry_security.ino`, `fire_protection.ino`,
`CalibrationConstants.h`) load automatically as part of the same
sketch.

## Wiring — matches `Circuit_summary.txt` exactly

| Arduino pin | Connected to |
|---|---|
| D0, D1 | **Unconnected** (reserved for USB serial / CSV debug output) |
| D2 | YF-S201/YF-B1 flow sensor, yellow signal wire (interrupt) |
| D3 | Active buzzer signal/IN |
| D4 | Pump relay IN (active-LOW) |
| D5 | SG90 servo signal (door lock) |
| D6 | DFPlayer Mini **TX** (Arduino D6 acts as RX) |
| D7 | DFPlayer Mini **RX**, through a **1 kΩ resistor** (Arduino D7 acts as TX) |
| D8 | DHT11 DATA |
| D9 | Humidifier relay IN (active-LOW, 24V load) |
| D10 | Fan relay IN (active-LOW, 12V load) |
| D13 | Status/alarm LED |
| A0 | HX711 DT/DOUT |
| A1 | HX711 SCK/CLK |
| A2 | TCRT5000 IR reflective sensor, AO (analog reflectance output) |
| A4 (SDA) | I2C — PCF8574 SDA (keypad expander only) |
| A5 (SCL) | I2C — PCF8574 SCL (keypad expander only) |

**PCF8574 (I2C address 0x20, A0/A1/A2 → GND)** → 4×4 keypad:
- P0–P3 = keypad rows R1–R4
- P4–P7 = keypad columns C1–C4

D11 and D12 are free — they previously carried the ESP-01 WiFi link,
which has been removed from this project.

## Why a PCF8574 I2C expander for the keypad

A Uno only has 18 usable I/O pins (D2–D13 + A0–A5, reserving D0/D1 for
USB/serial), and wiring the keypad, TCRT5000, servo, DFPlayer, buzzer,
DHT11, HX711, flow sensor, and 3 relays all directly would need more
pins than that. Routing the keypad through a PCF8574 I2C I/O expander
frees up 8 direct pins that a 4x4 matrix would otherwise need,
resolving the pin budget.

## Critical wiring notes

- **DFPlayer Mini RX also needs the 1 kΩ series resistor** on D7, per
  `Circuit_summary.txt` — make sure TX/RX are crossed correctly (D6 to
  the DFPlayer's TX pin, D7 to its RX pin).
- **All three relay modules are active-LOW** (HIGH = off, LOW =
  energizes the coil) — this is what the firmware assumes. Check your
  specific relay board's datasheet; if it's active-HIGH instead, swap
  the `HIGH`/`LOW` values in `setRelay()` and the initial pin states in
  `setup()`.
- **Never power the pump, fan, humidifier, or servo from the Arduino's
  5V pin.** Use a regulated external 5V supply for the servo and pump,
  a 12V supply for the fan, and the correct 24V adapter for the
  humidifier. Never connect 12V/24V to the Arduino's 5V rail.
- **Use the relay's NO (Normally Open) terminals only** — never NC —
  so pump/humidifier/fan default to off when the system powers up.
- **TCRT5000: connect only the AO pin** to A2. The module's own "DO" pin
  is a coincidental name match with Arduino's D0 (USB/Serial RX) — they
  are NOT the same pin, and connecting them creates a real conflict
  with Serial Monitor and uploads. Leave the module's DO disconnected.
- **Common ground**: every module's GND must be tied together —
  Arduino, sensors, PCF8574, HX711, DFPlayer, relay control sides,
  servo's external supply, and the 24V humidifier adapter.
- **Load cell wiring**: connect E+/E-/A+/A- to the HX711's matching
  labeled pads using the load cell's own wire labels, not assumed
  colors (these vary by manufacturer).

## DFPlayer Mini audio tracks

Place these as numbered MP3 files on the microSD card (track numbering
depends on your card's file order — see the DFRobotDFPlayerMini
library docs):

1. "PLEASE ENTER PASSWORD"
2. "ACCESS ACCEPTED"
3. "ACCESS DENIED"
4. "ACCESS DENIED, THIEF ATTEMPT"
5. "HIGH TEMPERATURE DETECTED"
6. "PIPE BLOCKAGE DETECTED"
7. "SYSTEM STABLE"

The buzzer on D3 sounds alongside track 4 whenever a thief attempt is
detected, and alongside track 5 for as long as the fire sequence is
active (silenced again once the system reports "SYSTEM STABLE").

## Required libraries (Arduino IDE → Library Manager)

- `DHT sensor library` (Adafruit) + `Adafruit Unified Sensor`
- `HX711` by Bogdan Necula
- `Servo` (built-in, no install needed)
- `DFRobotDFPlayerMini` by DFRobot

No PCF8574 library is needed — the keypad scan is bit-banged directly
over I2C (`Wire.h`, built in), keeping the I2C bus dependency-free
(it's now used only by the PCF8574, since the TCRT5000 photocell is
a simple analog connection with no I2C involved).

## Before uploading

1. Set your own accepted PIN in `CalibrationConstants.h`:
   ```cpp
   static const char* DOOR_PIN = "1234";
   ```
2. Calibrate the load cell's `scale.set_scale(...)` value in `setup()`
   using a known reference weight (placeholder value is a guess).
3. Calibrate `FLOW_CALIBRATION_FACTOR` in `CalibrationConstants.h`
   against your actual flow sensor's datasheet or your own 3-point
   calibration.
4. Adjust `doorServo.write(...)` open/closed angles in
   `entry_security.ino` to match your physical door mechanism.

## Fire-suppression sequence

The sequence runs entirely on the Arduino — there is no network
dependency:

1. Temp > `FIRE_THRESHOLD_C` → alarm LED on, buzzer sounds, "HIGH
   TEMPERATURE DETECTED" plays, pump turns on.
2. The pump runs for a fixed `PUMP_RUN_MS` (55 seconds). If the flow
   sensor reads at/below `FLOW_BLOCKAGE_LPM` at any point during that
   window, the pump stops immediately, the buzzer sounds, and "PIPE
   BLOCKAGE DETECTED" plays — the sequence halts until the blockage is
   physically cleared and the system is reset.
3. After 55 seconds (no blockage), the pump turns off and the
   humidifier turns on.
4. The humidifier stays on until humidity returns to
   `NORMAL_HUMIDITY_PCT` (from `CalibrationConstants.h`), then turns
   off, the buzzer silences, the alarm LED turns off, and "SYSTEM
   STABLE" plays.

## Ambient humidity fan control (independent of the fire sequence)

Separately from the fire-suppression sequence and humidifier above, the
fan on D10 watches ambient humidity on its own every sensor cycle:

- Humidity rises above `HUMIDITY_FAN_ON_PCT` (60%, in
  `CalibrationConstants.h`) → fan turns **on**.
- Humidity drops back to `NORMAL_HUMIDITY_PCT` (from
  `CalibrationConstants.h`) → fan turns **off**.

This uses separate on/off thresholds (hysteresis) so the fan doesn't
flicker on and off right at one boundary value. It runs regardless of
`fireStage`, and does not change or interact with the humidifier logic.

## Entry security

Wrong-PIN lockout is fully local: the Arduino compares each entry
against `DOOR_PIN` and counts wrong attempts itself, escalating to a
thief-attempt alarm (buzzer + "ACCESS DENIED, THIEF ATTEMPT") once
`MAX_WRONG_ATTEMPTS` is reached.

## Serial output is now a pure CSV data logger

All the hardware behavior above is unchanged. The Serial Monitor output
was redesigned into a machine-readable CSV stream for the Sensors &
Instrumentation report — there are no human-readable sentences on
Serial anymore. Exactly one header row prints at startup:

```
timestamp_ms,mode,sensor,sample_id,raw_value,filtered_value,calibrated_value,reference_value,error,error_percent,unit,status,event,calibration_point,trial,eeprom_address,eeprom_value
```

Every line after that is one CSV row: a per-sensor reading (`mode=NORMAL`),
a discrete event like `door_opened` or `fire_detected` (`mode=NORMAL`,
`event` column filled), a calibration-trial row (`mode=CALIB`), or a
periodic min/max/mean/stddev row (`mode=STATS`). Capture the Serial
Monitor output (or log it with a terminal tool) and import directly into
Excel/MATLAB/Python.

### Running a calibration

Send one of these (newline-terminated) over Serial to run a blocking
calibration routine against the reference points in
`CalibrationConstants.h`:

```
CAL:LOADCELL
CAL:FLOW
CAL:TEMP
CAL:HUMIDITY
CAL:OPTICAL
```

Each command logs `CAL_TRIALS_PER_POINT` CSV rows per reference point,
then saves an updated calibration factor/offset to EEPROM (logged as an
`eeprom_write` row). These calibration values only affect the
`calibrated_value` CSV column — `FIRE_THRESHOLD_C`,
`HUMIDITY_FAN_ON_PCT`, `NORMAL_HUMIDITY_PCT`, and `PHOTOCELL_THRESHOLD`
keep driving the actual fire/security decisions exactly as before, so
running a calibration never changes system behavior, only report data.
